/* ==========================================================================
 * MÓDULO: controlador_teclado_AT Con Transmisor UART
 * ========================================================================== */

module controlador_teclado_AT ( 
    input  wire       clk,        // Reloj maestro de la FPGA (50 MHz) PIN_P11
    input  wire       reset,      // Reset (KEY0 activo en bajo) PIN_B8
    input  wire [3:0] col,        // Entradas: Columnas del teclado (Pull-up) 
    output reg  [3:0] row,        // Salidas: Filas del teclado 
    output reg        led_accion, // LED físico en la placa (LEDR0)
    output wire [6:0] disp0,      // Display HEX0
    output wire [6:0] disp1,      // Display HEX1
    output wire [6:0] disp2,      // Display HEX2
    output wire [6:0] disp3,      // Display HEX3
    output wire       tx_out      // Salida Serial TX hacia el Arduino (Pin IO10)
); 

    // =======================================================================
    // 1. GENERADOR DE TICK (CLOCK ENABLE): 1 pulso cada 1 milisegundo
    // =======================================================================
    reg [15:0] cont_1ms;
    wire       tick_1ms = (cont_1ms == 16'd49_999); // Se hace 1 cada 50,000 ciclos

    always @(posedge clk or negedge reset) begin
        if (~reset) begin
            cont_1ms <= 16'd0;
        end else begin
            if (tick_1ms) cont_1ms <= 16'd0;
            else          cont_1ms <= cont_1ms + 1'b1;
        end
    end

    // =======================================================================
    // 2. MÁQUINA DE ESTADOS (FSM) PARA ESCANEO DE FILAS
    // =======================================================================
    localparam S0_FILA0 = 2'b00; 
    localparam S1_FILA1 = 2'b01; 
    localparam S2_FILA2 = 2'b10; 
    localparam S3_FILA3 = 2'b11; 

    reg [1:0] estado_actual, estado_siguiente; 

    always @(posedge clk) begin 
        if (~reset) begin
            estado_actual <= S0_FILA0; 
        end else if (tick_1ms) begin // <--- CLOCK ENABLE
            estado_actual <= estado_siguiente; 
        end
    end 

    always @(*) begin 
        case (estado_actual) 
            S0_FILA0: begin row = 4'b1110; estado_siguiente = S1_FILA1; end 
            S1_FILA1: begin row = 4'b1101; estado_siguiente = S2_FILA2; end 
            S2_FILA2: begin row = 4'b1011; estado_siguiente = S3_FILA3; end 
            S3_FILA3: begin row = 4'b0111; estado_siguiente = S0_FILA0; end 
            default:  begin row = 4'b1111; estado_siguiente = S0_FILA0; end 
        endcase 
    end 

    // =======================================================================
    // 3. DECODIFICADOR COMBINACIONAL: MATRIZ -> ASCII
    // =======================================================================
    reg [7:0] ascii_data; 
    reg       tecla_detectada; 

    always @(*) begin 
        ascii_data = 8'h00; 
        tecla_detectada = 1'b0; 
        case ({estado_actual, col}) 
            {S0_FILA0, 4'b1110}: begin ascii_data = 8'h31; tecla_detectada = 1'b1; end // '1' 
            {S0_FILA0, 4'b1101}: begin ascii_data = 8'h32; tecla_detectada = 1'b1; end // '2' 
            {S0_FILA0, 4'b1011}: begin ascii_data = 8'h33; tecla_detectada = 1'b1; end // '3' 
            {S0_FILA0, 4'b0111}: begin ascii_data = 8'h41; tecla_detectada = 1'b1; end // 'A' 
            {S1_FILA1, 4'b1110}: begin ascii_data = 8'h34; tecla_detectada = 1'b1; end // '4' 
            {S1_FILA1, 4'b1101}: begin ascii_data = 8'h35; tecla_detectada = 1'b1; end // '5' 
            {S1_FILA1, 4'b1011}: begin ascii_data = 8'h36; tecla_detectada = 1'b1; end // '6' 
            {S1_FILA1, 4'b0111}: begin ascii_data = 8'h42; tecla_detectada = 1'b1; end // 'B' 
            {S2_FILA2, 4'b1110}: begin ascii_data = 8'h37; tecla_detectada = 1'b1; end // '7' 
            {S2_FILA2, 4'b1101}: begin ascii_data = 8'h38; tecla_detectada = 1'b1; end // '8' 
            {S2_FILA2, 4'b1011}: begin ascii_data = 8'h39; tecla_detectada = 1'b1; end // '9' 
            {S2_FILA2, 4'b0111}: begin ascii_data = 8'h43; tecla_detectada = 1'b1; end // 'C' 
            {S3_FILA3, 4'b1110}: begin ascii_data = 8'h2A; tecla_detectada = 1'b1; end // '*' 
            {S3_FILA3, 4'b1101}: begin ascii_data = 8'h30; tecla_detectada = 1'b1; end // '0' 
            {S3_FILA3, 4'b1011}: begin ascii_data = 8'h23; tecla_detectada = 1'b1; end // '#' 
            {S3_FILA3, 4'b0111}: begin ascii_data = 8'h44; tecla_detectada = 1'b1; end // 'D' 
            default: begin ascii_data = 8'h00; tecla_detectada = 1'b0; end 
        endcase 
    end 

    // =======================================================================
    // 4. GESTIÓN DE MEMORIA Y FILTRO ANTIRREBOTE (20ms)
    // =======================================================================
    reg [7:0] reg0, reg1, reg2, reg3;
    reg       tecla_bloqueada; 
    reg [4:0] temporizador; 
    reg [1:0] ptr_direccion;    
    
    wire pulso_escritura = tecla_detectada & ~tecla_bloqueada; 

    // INSTANCIA DEL TRANSMISOR SERIAL (Envía la tecla detectada a la PC)
    uart_tx transmisor (
        .clk(clk),
        .tx_start(pulso_escritura),
        .tx_data(ascii_data),
        .tx(tx_out)
    );

    // Reloj 50MHz, pero la lógica avanza con el tick_1ms
    always @(posedge clk) begin 
        if (~reset) begin 
            reg0 <= 8'h00; reg1 <= 8'h00; 
            reg2 <= 8'h00; reg3 <= 8'h00; 
            ptr_direccion <= 2'b00; 
            tecla_bloqueada <= 1'b0; 
            temporizador <= 5'd0; 
        end else if (tick_1ms) begin // <--- CLOCK ENABLE
            
            if (tecla_detectada) begin 
                tecla_bloqueada <= 1'b1;     
                temporizador <= 5'd0;       
            end else begin 
                if (temporizador < 5'd20) begin 
                    temporizador <= temporizador + 1'b1; 
                end else begin 
                    tecla_bloqueada <= 1'b0; 
                end 
            end 

            if (pulso_escritura) begin  
                case (ptr_direccion) 
                    2'b00: reg0 <= ascii_data; 
                    2'b01: reg1 <= ascii_data; 
                    2'b10: reg2 <= ascii_data; 
                    2'b11: reg3 <= ascii_data; 
                endcase 
                ptr_direccion <= ptr_direccion + 1'b1; 
            end 
        end 
    end 

    // =======================================================================
    // 5. EJECUCIÓN DE COMANDO REAL (Contraseña de 4 caracteres)
    // =======================================================================
    always @(posedge clk) begin
        if (~reset) begin
            led_accion <= 1'b0;
        end else begin
            // Comando ON: "A001" (A, 0, 0, 1)
            if (reg0 == 8'h41 && reg1 == 8'h30 && reg2 == 8'h30 && reg3 == 8'h31)      
                led_accion <= 1'b1; 
                
            // Comando OFF: "A000" (A, 0, 0, 0)
            else if (reg0 == 8'h41 && reg1 == 8'h30 && reg2 == 8'h30 && reg3 == 8'h30) 
                led_accion <= 1'b0; 
        end
    end

    // =======================================================================
    // 6. DECODIFICADORES DE PANTALLA (Izquierda a Derecha)
    // =======================================================================
    decodificador_7seg u3 (.ascii(reg0), .seg(disp3)); 
    decodificador_7seg u2 (.ascii(reg1), .seg(disp2)); 
    decodificador_7seg u1 (.ascii(reg2), .seg(disp1)); 
    decodificador_7seg u0 (.ascii(reg3), .seg(disp0));
endmodule

// =======================================================================
// SUBMÓDULO 1: DECODIFICADOR ASCII -> 7 SEGMENTOS
// =======================================================================
module decodificador_7seg (
    input  wire [7:0] ascii,
    output reg  [6:0] seg
);
    always @(*) begin
        case (ascii)
            8'h30: seg = 7'b1000000; // '0'
            8'h31: seg = 7'b1111001; // '1'
            8'h32: seg = 7'b0100100; // '2'
            8'h33: seg = 7'b0110000; // '3'
            8'h34: seg = 7'b0011001; // '4'
            8'h35: seg = 7'b0010010; // '5'
            8'h36: seg = 7'b0000010; // '6'
            8'h37: seg = 7'b1111000; // '7'
            8'h38: seg = 7'b0000000; // '8'
            8'h39: seg = 7'b0011000; // '9'
            8'h41: seg = 7'b0001000; // 'A'
            8'h42: seg = 7'b0000011; // 'B'
            8'h43: seg = 7'b1000110; // 'C'
            8'h44: seg = 7'b0100001; // 'D'
            8'h2A: seg = 7'b0011100; // '*'
            8'h23: seg = 7'b1001000; // '#'
            8'h00: seg = 7'b1111111; // Apagado
            default: seg = 7'b1111111;
        endcase
    end
endmodule

// =======================================================================
// ¡NUEVO! SUBMÓDULO 2: TRANSMISOR UART (9600 Baudios a 50 MHz)
// =======================================================================
module uart_tx (
    input wire clk,
    input wire tx_start,
    input wire [7:0] tx_data,
    output reg tx
);
    parameter BIT_TMR_MAX = 5208; // (50MHz / 9600 baudios)
    
    reg [12:0] bit_tmr = 0;
    reg [3:0]  bit_idx = 0;
    reg [9:0]  shift_reg = 0;
    reg        estado = 0; // 0 = IDLE, 1 = TRANSMITIENDO
    
    initial tx = 1'b1;
    
    always @(posedge clk) begin
        if (estado == 0) begin
            tx <= 1'b1;
            if (tx_start) begin
                shift_reg <= {1'b1, tx_data, 1'b0}; // Bit Stop(1) + Datos + Bit Start(0)
                estado <= 1;
                bit_tmr <= 0;
                bit_idx <= 0;
            end
        end else begin
            if (bit_tmr == BIT_TMR_MAX - 1) begin
                bit_tmr <= 0;
                tx <= shift_reg[0];
                shift_reg <= {1'b1, shift_reg[9:1]};
                
                if (bit_idx == 9) estado <= 0;
                else bit_idx <= bit_idx + 1;
            end else begin
                bit_tmr <= bit_tmr + 1;
            end
        end
    end
endmodule