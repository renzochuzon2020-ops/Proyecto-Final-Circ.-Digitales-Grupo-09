/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";

interface CommandLog {
  id: string;
  time: string;
  code: string;
  action: string;
}

interface Channel {
  id: string;
  name: string;
  bgUrl: string;
  resolution: string;
  frequency: string;
}

export default function App() {
  // Reloj dinámico en vivo
  const [time, setTime] = useState<string>("13:25:28");
  const [dateStr, setDateStr] = useState<string>("lun, 29 jun");
  const [isLiveClock, setIsLiveClock] = useState<boolean>(true);

  // Reloj en vivo
  useEffect(() => {
    if (!isLiveClock) return;
    const updateTime = () => {
      const now = new Date();
      const hrs = String(now.getHours()).padStart(2, "0");
      const mins = String(now.getMinutes()).padStart(2, "0");
      const secs = String(now.getSeconds()).padStart(2, "0");
      setTime(`${hrs}:${mins}:${secs}`);
      
      const options: Intl.DateTimeFormatOptions = { weekday: "short", month: "short", day: "numeric" };
      setDateStr(now.toLocaleDateString("es-ES", options));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [isLiveClock]);

  // Control de Volumen
  const [volume, setVolume] = useState<number>(65);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Lista de canales
  const channelsList: Channel[] = [
    {
      id: "04",
      name: "Red de Noticias Local",
      bgUrl: "https://images.unsplash.com/photo-1585829365295-ab7cd400c167?auto=format&fit=crop&q=80&w=600",
      resolution: "1080p",
      frequency: "60Hz"
    },
    {
      id: "07",
      name: "CineMax Premiere",
      bgUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=600",
      resolution: "4K UHD",
      frequency: "60Hz"
    },
    {
      id: "12",
      name: "Artículo Cientifico Astra",
      bgUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=600",
      resolution: "1080p",
      frequency: "120Hz"
    },
    {
      id: "24",
      name: "Radio Retro Soundwave",
      bgUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=600",
      resolution: "720p",
      frequency: "50Hz"
    },
    {
      id: "99",
      name: "Mapa de Diagnóstico de Señal FPGA",
      bgUrl: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=600",
      resolution: "1080p",
      frequency: "144Hz"
    }
  ];

  const [activeChannelIdx, setActiveChannelIdx] = useState<number>(0);
  const currentChannel = channelsList[activeChannelIdx];

  // Entrada de teclado y buffer de comandos
  const [keypadBuffer, setKeypadBuffer] = useState<string>("");
  const [pressedKey, setPressedKey] = useState<string | null>(null);

  // Historial de comandos
  const [logs, setLogs] = useState<CommandLog[]>([
    { id: "1", time: "13:25:01", code: "0011", action: "Seleccionar Canal 1 (CH04)" },
    { id: "2", time: "13:24:42", code: "0003", action: "Volumen incrementado a 70%" },
    { id: "3", time: "13:23:15", code: "0033", action: "Lanzamiento: YouTube" },
    { id: "4", time: "13:20:00", code: "0005", action: "Audio Silenciado (MUTE)" },
    { id: "5", time: "13:18:52", code: "0012", action: "Seleccionar Canal 2 (CH07)" }
  ]);

  const logsContainerRef = useRef<HTMLDivElement>(null);

  // Añadir función en el historial cuando están los 10 comandos
  const addLog = (code: string, action: string) => {
    const now = new Date();
    const formattedTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}`;
    const newEntry: CommandLog = {
      id: String(Date.now() + Math.random()),
      time: formattedTime,
      code,
      action
    };
    setLogs((prev) => [newEntry, ...prev].slice(0, 10));
  };

  // Abrir aplicaciones al ejecutar comandos
  const handleLaunchApp = (appName: string) => {
    let url = "";
    if (appName === "Netflix") {
      url = "https://www.netflix.com";
      setActiveChannelIdx(1); // CineMax Premiere
    } else if (appName === "Spotify") {
      url = "https://open.spotify.com";
      setActiveChannelIdx(3); // Radio Retro
    } else if (appName === "YouTube") {
      url = "https://www.youtube.com";
      setActiveChannelIdx(3); // Radio Retro
    } else if (appName === "Prime Video") {
      url = "https://www.primevideo.com";
      setActiveChannelIdx(1); // CineMax Premiere
    } else if (appName === "Disney+") {
      url = "https://www.disneyplus.com";
      setActiveChannelIdx(2); // Astra Scientific
    } else if (appName === "Cable TV") {
      url = "https://pluto.tv";
      setActiveChannelIdx(0); // Red de Noticias Local
    }

    if (url) {
      window.open(url, "_blank");
    }
  };

  // Ajuste de volumen en la web
  const handleVolumeChange = (newVal: number) => {
    if (newVal < 0) newVal = 0;
    if (newVal > 100) newVal = 100;
    setVolume(newVal);
    if (isMuted && newVal > 0) {
      setIsMuted(false);
    }
  };

  // Procesar y ejecutar los 4 comandos
  const evaluateBuffer = (buf: string) => {
    const cleanBuf = buf.trim();

    switch (cleanBuf) {
      case "0000":
        setVolume(65);
        setIsMuted(false);
        setActiveChannelIdx(0);
        addLog("0000", "Restablecer de Fábrica (RESET)");
        break;
      case "0001": {
        const nextIdx = (activeChannelIdx + 1) % channelsList.length;
        setActiveChannelIdx(nextIdx);
        addLog("0001", `Siguiente Canal (CH++) ➔ CH${channelsList[nextIdx].id}`);
        break;
      }
      case "0002": {
        const prevIdx = (activeChannelIdx - 1 + channelsList.length) % channelsList.length;
        setActiveChannelIdx(prevIdx);
        addLog("0002", `Canal Anterior (CH--) ➔ CH${channelsList[prevIdx].id}`);
        break;
      }
      case "0003": {
        const nextVol = Math.min(volume + 6, 100);
        handleVolumeChange(nextVol);
        addLog("0003", `Volumen incrementado a ${nextVol}%`);
        break;
      }
      case "0004": {
        const prevVol = Math.max(volume - 6, 0);
        handleVolumeChange(prevVol);
        addLog("0004", `Volumen disminuido a ${prevVol}%`);
        break;
      }
      case "0005":
        setIsMuted(true);
        addLog("0005", "Audio Silenciado (MUTE ON)");
        break;
      case "0006":
        setIsMuted(false);
        addLog("0006", "Audio Reactivado (MUTE OFF)");
        break;
      case "0011":
        setActiveChannelIdx(0);
        addLog("0011", `Selección Canal: CH04 (${channelsList[0].name})`);
        break;
      case "0012":
        setActiveChannelIdx(1);
        addLog("0012", `Selección Canal: CH07 (${channelsList[1].name})`);
        break;
      case "0013":
        setActiveChannelIdx(2);
        addLog("0013", `Selección Canal: CH12 (${channelsList[2].name})`);
        break;
      case "0014":
        setActiveChannelIdx(3);
        addLog("0014", `Selección Canal: CH24 (${channelsList[3].name})`);
        break;
      case "0015":
        setActiveChannelIdx(4);
        addLog("0015", `Selección Canal: CH99 (${channelsList[4].name})`);
        break;
      case "0031":
        handleLaunchApp("Netflix");
        addLog("0031", "Lanzamiento: Netflix");
        break;
      case "0032":
        handleLaunchApp("Spotify");
        addLog("0032", "Lanzamiento: Spotify");
        break;
      case "0033":
        handleLaunchApp("YouTube");
        addLog("0033", "Lanzamiento: YouTube");
        break;
      case "0034":
        handleLaunchApp("Prime Video");
        addLog("0034", "Lanzamiento: Prime Video");
        break;
      case "0035":
        handleLaunchApp("Disney+");
        addLog("0035", "Lanzamiento: Disney+");
        break;
      case "0036":
        handleLaunchApp("Cable TV");
        addLog("0036", "Lanzamiento: Cable TV");
        break;
      default:
        addLog(cleanBuf, "Secuencia de comando inválida");
        break;
    }
  };

  // Emulador de teclado
  const handleKeyPress = (key: string) => {
    setPressedKey(key);
    setTimeout(() => setPressedKey(null), 150);

    if (key === "#") {
      if (keypadBuffer.length === 4) {
        evaluateBuffer(keypadBuffer);
        setKeypadBuffer("");
      } else if (keypadBuffer.length > 0) {
        addLog(keypadBuffer, "Error: Código incompleto (requiere 4 dígitos)");
        setKeypadBuffer("");
      }
    } else if (key === "*") {
      setKeypadBuffer("");
      addLog("CLR", "Marcación cancelada / Buffer limpio");
    } else {
      if (keypadBuffer.length < 4) {
        const nextBuf = keypadBuffer + key;
        setKeypadBuffer(nextBuf);

        if (nextBuf.length === 4) {
          setTimeout(() => {
            evaluateBuffer(nextBuf);
            setKeypadBuffer("");
          }, 350);
        }
      }
    }
  };

  // Configura los eventos de teclado
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === "INPUT" || activeEl.tagName === "TEXTAREA" || activeEl.tagName === "SELECT")) {
        return;
      }

      let key = e.key.toUpperCase();
      if (e.key === "Enter") key = "#";
      if (e.key === "Backspace" || e.key === "Escape") key = "*";

      const validKeys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "A", "B", "C", "D", "*", "#"];
      if (validKeys.includes(key)) {
        e.preventDefault();
        handleKeyPress(key);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [keypadBuffer, activeChannelIdx, volume, isMuted]);

  return (
    <div className="min-h-screen w-full flex flex-col font-sans text-on-surface-variant relative p-2 md:p-4 bg-surface selection:bg-primary-fixed select-none">
      
      {/* Decorative ambient blurred nodes */}
      <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden bg-yellow-50/15">
        <div className="absolute top-[-10%] left-[-5%] w-[45vw] h-[45vw] rounded-full bg-blue-200/20 blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-5%] w-[55vw] h-[55vw] rounded-full bg-teal-100/20 blur-[140px]"></div>
        <div className="absolute top-[20%] right-[15%] w-[35vw] h-[35vw] rounded-full bg-purple-100/15 blur-[100px]"></div>
      </div>

      <main className="flex-grow w-full max-w-7xl mx-auto grid grid-cols-12 gap-3 md:gap-4 relative z-10 min-h-0">
        
        {/* ========================================================= */}
        {/* COLUMNA IZQUIERDA */}
        {/* ========================================================= */}
        <div className="col-span-12 lg:col-span-8 flex flex-col gap-3 md:gap-4 min-h-0">
          
          {/* HEADER NAV BAR */}
          <div className="glass-panel p-3.5 flex flex-wrap items-center justify-between gap-4 flex-shrink-0" id="header-nav-bar">
            <div className="flex items-center gap-3">
              <div 
                className="flex items-center gap-2.5 cursor-pointer hover:opacity-80 transition-all"
                onClick={() => {
                  addLog("SYS", "Solicitud de verificación de estado");
                }}
              >
                <span className="material-symbols-outlined text-primary-container fill-1 animate-pulse text-2xl md:text-3xl">smart_display</span>
                <div className="flex flex-col justify-center select-none">
                  <span className="bg-gradient-to-r from-primary to-primary-container bg-clip-text text-transparent font-black text-sm md:text-base leading-none tracking-tight">Transmisor AT</span>
                  <span className="text-[10px] md:text-[11px] font-bold text-outline leading-none mt-0.5 tracking-wider">PQT App</span>
                </div>
              </div>
              <div className="h-5 w-px bg-surface-variant hidden sm:block"></div>
              
              {/* Only Panel Control left as per instructions */}
              <div className="flex gap-1.5 py-0.5">
                <div 
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-primary text-white shadow-md shadow-primary/20"
                  id="tab-dashboard"
                >
                  <span className="material-symbols-outlined text-sm">space_dashboard</span>
                  <span>Panel Control</span>
                </div>
              </div>
            </div>

            {/* Live clock profile section */}
            <div className="flex items-center gap-3.5 ml-auto sm:ml-0">
              <div 
                className="text-center cursor-pointer group"
                onClick={() => {
                  setIsLiveClock(!isLiveClock);
                  addLog("CLK", isLiveClock ? "Reloj configurado en congelamiento" : "Sincronizando reloj UTC en vivo");
                }}
                title={isLiveClock ? "Clic para congelar el reloj" : "Clic para sincronizar hora UTC en vivo"}
              >
                <div className="font-bold text-on-surface text-sm font-mono tracking-wider flex items-center gap-1 justify-center">
                  <span className={`w-1.5 h-1.5 rounded-full ${isLiveClock ? "bg-green-500 animate-ping" : "bg-orange-400"}`}></span>
                  {time}
                </div>
                <div className="text-[10px] text-outline font-semibold tracking-wide transition-colors group-hover:text-primary">
                  {dateStr} {!isLiveClock && "(Congelado)"}
                </div>
              </div>
              
              <button 
                onClick={() => {
                  addLog("USR", "Perfil Andrea Rodriguez consultado");
                  alert("Sesión iniciada como Andrea Rodriguez - Perfil de Desarrollador de Transmisor AT verificado.");
                }}
                className="w-8 h-8 rounded-full bg-purple-100/90 shadow-sm flex items-center justify-center text-purple-700 hover:bg-purple-200 transition-colors cursor-pointer border border-purple-200/40"
                title="Ver credenciales de usuario"
                id="profile-avatar-btn"
              >
                <span className="material-symbols-outlined text-[16px] font-bold">person</span>
              </button>
            </div>
          </div>

          {/* SYSTEM APPLICATIONS CAROUSEL (Now interactive and opens URLs!) */}
          <div className="glass-panel p-4 flex flex-col justify-between flex-shrink-0" id="apps-recommended-container">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-headline-md text-base md:text-lg text-on-surface flex items-center gap-2">
                <span className="material-symbols-outlined text-orange-500 text-[18px]">grid_view</span>
                <span>Aplicaciones del Sistema</span>
              </h3>
              <span className="text-[10px] bg-green-50 text-green-700 border border-green-200/50 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider animate-pulse">
                Acceso Directo
              </span>
            </div>
            
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5" id="apps-scrollable-row">
              <button 
                onClick={() => evaluateBuffer("0031")}
                className="app-icon bg-gradient-to-br from-red-500/80 to-red-700/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 shadow cursor-pointer text-center"
                id="app-netflix"
                title="Comando 0031"
              >
                <span className="material-symbols-outlined text-xl">play_circle</span>
                <span className="text-[11px] font-bold tracking-wide">Netflix</span>
              </button>
              
              <button 
                onClick={() => evaluateBuffer("0032")}
                className="app-icon bg-gradient-to-br from-green-500/80 to-green-700/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 shadow cursor-pointer text-center"
                id="app-spotify"
                title="Comando 0032"
              >
                <span className="material-symbols-outlined text-xl">music_note</span>
                <span className="text-[11px] font-bold tracking-wide">Spotify</span>
              </button>

              <button 
                onClick={() => evaluateBuffer("0033")}
                className="app-icon bg-gradient-to-br from-red-600/80 to-red-800/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 shadow cursor-pointer text-center"
                id="app-youtube"
                title="Comando 0033"
              >
                <span className="material-symbols-outlined text-xl">smart_display</span>
                <span className="text-[11px] font-bold tracking-wide">YouTube</span>
              </button>

              <button 
                onClick={() => evaluateBuffer("0034")}
                className="app-icon bg-gradient-to-br from-blue-400/80 to-blue-600/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 shadow cursor-pointer text-center"
                id="app-prime"
                title="Comando 0034"
              >
                <span className="material-symbols-outlined text-xl">shopping_bag</span>
                <span className="text-[11px] font-bold tracking-wide">Prime Video</span>
              </button>

              <button 
                onClick={() => evaluateBuffer("0035")}
                className="app-icon bg-gradient-to-br from-blue-600/80 to-blue-900/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 shadow cursor-pointer text-center"
                id="app-disney"
                title="Comando 0035"
              >
                <span className="material-symbols-outlined text-xl">movie</span>
                <span className="text-[11px] font-bold tracking-wide">Disney+</span>
              </button>

              <button 
                onClick={() => evaluateBuffer("0036")}
                className="app-icon bg-gradient-to-br from-gray-500/80 to-gray-700/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 shadow cursor-pointer text-center"
                id="app-cable"
                title="Comando 0036"
              >
                <span className="material-symbols-outlined text-xl">settings_input_antenna</span>
                <span className="text-[11px] font-bold tracking-wide">Cable TV</span>
              </button>
            </div>
          </div>

          {/* LOWER TWO-COLUMN GRID: DIRECTORY AND THE TERMINAL HISTORIAL */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4 flex-grow min-h-0">
            
            {/* DIRECTORY OF COMMANDS (REDUCED TO REMAINING 3 CATEGORIES) */}
            <div className="glass-panel p-4 flex flex-col h-full min-h-[400px] md:min-h-0" id="command-directory-container">
              
              {/* Header with "Marcado" keypad buffer display */}
              <div className="flex flex-wrap items-center justify-between gap-3 mb-3 border-b border-surface-variant/40 pb-2.5 flex-shrink-0">
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-green-600 bg-green-50 p-1 rounded-lg text-sm font-bold">menu_book</span>
                  <div>
                    <h3 className="text-xs font-bold text-on-surface tracking-tight">
                      Directorios AT
                    </h3>
                    <p className="text-[9px] text-outline">
                      Sintonizador, Audio y Apps
                    </p>
                  </div>
                </div>
                
                {/* MARCADO LED display */}
                <div className="flex items-center gap-1.5 bg-slate-950 text-slate-100 p-1.5 rounded-lg border border-slate-800 shadow-inner">
                  <span className="text-[9px] text-slate-400 font-mono uppercase tracking-wider">Marcado:</span>
                  <div className="flex gap-0.5">
                    {[0, 1, 2, 3].map((idx) => {
                      const char = keypadBuffer[idx] || "";
                      return (
                        <span 
                          key={idx} 
                          className={`w-4 h-5 rounded bg-slate-900 border border-slate-800 flex items-center justify-center font-mono font-bold text-[10px] ${
                            char ? "text-yellow-400 animate-pulse" : "text-slate-600"
                          }`}
                        >
                          {char || "_"}
                        </span>
                      );
                    })}
                  </div>
                  <span className="text-[8px] text-green-400 font-mono animate-pulse font-bold">
                    {keypadBuffer.length === 4 ? "OK" : "..."}
                  </span>
                </div>
              </div>

              {/* Scrollable list of commands categories */}
              <div className="overflow-y-auto pr-1 custom-scrollbar flex-grow space-y-3.5 max-h-[350px]">
                {/* CATEGORY 1: TUNER & CHANNELS */}
                <div>
                  <h4 className="text-[11px] font-bold text-on-surface flex items-center gap-1 mb-1.5 sticky top-0 bg-white/95 backdrop-blur-sm py-0.5 z-10">
                    <span className="material-symbols-outlined text-[12px] text-blue-500">settings_input_antenna</span>
                    Sintonizador de Canales
                  </h4>
                  <div className="grid grid-cols-1 gap-1 text-[11px]">
                    {[
                      { code: "0001", label: "Siguiente Canal (CH++)", desc: "Avanza al próximo canal sintonizado" },
                      { code: "0002", label: "Canal Anterior (CH--)", desc: "Retrocede al canal sintonizado" },
                      { code: "0011", label: "Sintonizar CH04 (Noticias)", desc: "Establece directamente el canal de noticias local" },
                      { code: "0012", label: "Sintonizar CH07 (CineMax)", desc: "Establece directamente CineMax Premiere" },
                      { code: "0013", label: "Sintonizar CH12 (Astra)", desc: "Establece directamente Astra Scientific" },
                      { code: "0014", label: "Sintonizar CH24 (Radio)", desc: "Establece directamente Radio Retro Soundwave" },
                      { code: "0015", label: "Sintonizar CH99 (Diagnóstico)", desc: "Establece directamente el canal de diagnóstico" },
                    ].map((cmd) => (
                      <button
                        key={cmd.code}
                        onClick={() => evaluateBuffer(cmd.code)}
                        className="flex items-center justify-between p-1.5 rounded-lg border border-surface-variant bg-white/50 hover:bg-primary/5 hover:border-primary transition-all text-left group"
                      >
                        <div className="flex flex-col">
                          <span className="font-bold text-[10px] text-on-surface group-hover:text-primary transition-colors">{cmd.label}</span>
                          <span className="text-[9px] text-outline-variant line-clamp-1">{cmd.desc}</span>
                        </div>
                        <span className="font-mono text-[9px] font-bold bg-blue-50 text-blue-700 border border-blue-100 px-1.5 py-0.2 rounded shadow-sm group-hover:bg-primary group-hover:text-white transition-all">
                          {cmd.code}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* CATEGORY 2: AUDIO CONTROL */}
                <div>
                  <h4 className="text-[11px] font-bold text-on-surface flex items-center gap-1 mb-1.5 sticky top-0 bg-white/95 backdrop-blur-sm py-0.5 z-10">
                    <span className="material-symbols-outlined text-[12px] text-orange-500">volume_up</span>
                    Control de Audio
                  </h4>
                  <div className="grid grid-cols-1 gap-1 text-[11px]">
                    {[
                      { code: "0003", label: "Incrementar Volumen +6%", desc: "Aumenta la ganancia de audio de la placa" },
                      { code: "0004", label: "Disminuir Volumen -6%", desc: "Disminuye la ganancia de audio de la placa" },
                      { code: "0005", label: "Silenciar Audio (Mute)", desc: "Corta la salida analógica de la placa" },
                      { code: "0006", label: "Reactivar Audio (Unmute)", desc: "Restaura la salida analógica de la placa" },
                    ].map((cmd) => (
                      <button
                        key={cmd.code}
                        onClick={() => evaluateBuffer(cmd.code)}
                        className="flex items-center justify-between p-1.5 rounded-lg border border-surface-variant bg-white/50 hover:bg-primary/5 hover:border-primary transition-all text-left group"
                      >
                        <div className="flex flex-col">
                          <span className="font-bold text-[10px] text-on-surface group-hover:text-primary transition-colors">{cmd.label}</span>
                          <span className="text-[9px] text-outline-variant line-clamp-1">{cmd.desc}</span>
                        </div>
                        <span className="font-mono text-[9px] font-bold bg-orange-50 text-orange-700 border border-orange-100 px-1.5 py-0.2 rounded shadow-sm group-hover:bg-primary group-hover:text-white transition-all">
                          {cmd.code}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* CATEGORY 3: SYSTEM APPLICATIONS */}
                <div>
                  <h4 className="text-[11px] font-bold text-on-surface flex items-center gap-1 mb-1.5 sticky top-0 bg-white/95 backdrop-blur-sm py-0.5 z-10">
                    <span className="material-symbols-outlined text-[12px] text-purple-500">apps</span>
                    Lanzamiento de Aplicaciones
                  </h4>
                  <div className="grid grid-cols-1 gap-1 text-[11px]">
                    {[
                      { code: "0031", label: "Iniciar Netflix", desc: "Abre el sitio oficial de Netflix en pestaña nueva" },
                      { code: "0032", label: "Iniciar Spotify", desc: "Abre el reproductor web de Spotify en pestaña nueva" },
                      { code: "0033", label: "Iniciar YouTube", desc: "Abre la plataforma de YouTube en pestaña nueva" },
                      { code: "0034", label: "Iniciar Prime Video", desc: "Abre Prime Video en pestaña nueva" },
                      { code: "0035", label: "Iniciar Disney+", desc: "Abre Disney+ en pestaña nueva" },
                      { code: "0036", label: "Iniciar Cable TV", desc: "Abre Pluto TV para TV en vivo en pestaña nueva" },
                    ].map((cmd) => (
                      <button
                        key={cmd.code}
                        onClick={() => evaluateBuffer(cmd.code)}
                        className="flex items-center justify-between p-1.5 rounded-lg border border-surface-variant bg-white/50 hover:bg-primary/5 hover:border-primary transition-all text-left group"
                      >
                        <div className="flex flex-col">
                          <span className="font-bold text-[10px] text-on-surface group-hover:text-primary transition-colors">{cmd.label}</span>
                          <span className="text-[9px] text-outline-variant line-clamp-1">{cmd.desc}</span>
                        </div>
                        <span className="font-mono text-[9px] font-bold bg-purple-50 text-purple-700 border border-purple-100 px-1.5 py-0.2 rounded shadow-sm group-hover:bg-primary group-hover:text-white transition-all">
                          {cmd.code}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* NEW COMPONENT: HISTORIAL DE COMANDOS (ELEGANT RETRO TERMINAL/TABLE) */}
            <div className="glass-panel p-4 flex flex-col bg-white/90 text-slate-900 border border-slate-200/60 shadow-inner min-h-[400px] md:min-h-0" id="command-history-container">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2.5 mb-3 flex-shrink-0">
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-green-700 bg-green-50 p-1.5 rounded-lg border border-green-200/50 text-sm font-bold animate-pulse">terminal</span>
                  <div>
                    <h3 className="text-xs font-mono font-bold text-slate-900 tracking-tight">
                      Historial de Comandos
                    </h3>
                    <p className="text-[9px] text-slate-500 font-mono">
                      Consola de ejecución (últimos 10)
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => setLogs([])}
                  className="text-[9px] bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-600 font-mono py-1 px-2.5 rounded transition-all cursor-pointer hover:text-slate-900"
                >
                  Limpiar
                </button>
              </div>

              {/* Terminal List Body */}
              <div className="flex-grow overflow-y-auto pr-1 custom-scrollbar font-mono text-[10px] space-y-1.5 max-h-[350px]" ref={logsContainerRef}>
                {logs.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400 py-16">
                    <span className="material-symbols-outlined text-2xl mb-1 text-slate-300">terminal_off</span>
                    <p className="text-[9px]">No hay comandos registrados</p>
                  </div>
                ) : (
                  logs.map((log) => (
                    <div 
                      key={log.id} 
                      className="flex items-center gap-1.5 py-0.5 px-1 rounded hover:bg-slate-100/60 transition-colors"
                    >
                      <span className="text-emerald-700 text-[9px] font-semibold">{log.time}</span>
                      <span className="text-slate-300 font-semibold">|</span>
                      <span className="text-black font-bold bg-yellow-400/90 px-1.5 py-0.5 rounded text-[9px] tracking-wide border border-yellow-500/30">{log.code}</span>
                      <span className="text-slate-300 font-semibold">|</span>
                      <span className="text-black text-[10px] font-bold leading-tight">{log.action}</span>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>
        </div>

        {/* ========================================================= */}
        {/* COLUMNA DERECHA */}
        {/* ========================================================= */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-3 md:gap-4 min-h-0">
          
          {/* NOW PLAYING TELEVISION OSD */}
          <div 
            className="glass-panel cinematic-bg flex flex-col justify-between h-[180px] md:h-[220px] lg:h-[35%] min-h-[180px] flex-shrink-0 relative overflow-hidden bg-cover bg-center transition-all duration-500 animate-fadeIn" 
            style={{ backgroundImage: `url('${currentChannel.bgUrl}')` }}
            id="channel-osd-panel"
          >
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent z-0"></div>
            
            {/* TV watermark icon */}
            <div className="absolute -right-8 -bottom-8 opacity-10 z-0">
              <span className="material-symbols-outlined text-[120px] text-white fill-1">tv</span>
            </div>

            <div className="p-4 md:p-5 flex flex-col h-full relative z-10 justify-between">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-[10px] text-white/90 tracking-widest font-bold uppercase drop-shadow-md">
                    REPRODUCIENDO AHORA
                  </h2>
                  <div className="text-5xl md:text-6xl font-black text-white leading-none tracking-tighter drop-shadow-lg flex items-baseline gap-2">
                    {currentChannel.id}
                    <span className="text-[11px] font-bold text-blue-300 tracking-wider">CH</span>
                  </div>
                  <h3 className="text-sm md:text-base font-bold text-white mt-1 drop-shadow-md line-clamp-1">
                    {currentChannel.name}
                  </h3>
                </div>
                
                <div className="flex flex-col items-end gap-1.5">
                  <div className="osd-overlay px-2.5 py-1 flex items-center gap-1.5 shadow-lg">
                    <span className="material-symbols-outlined text-red-500 text-[11px] animate-pulse">fiber_manual_record</span>
                    <span className="text-[8px] uppercase font-bold tracking-widest text-white">En Vivo</span>
                  </div>
                  
                  <div className="osd-overlay px-2 py-0.5 border border-white/10 text-[8px] uppercase tracking-wider text-yellow-300 font-mono shadow-md">
                    Control Canal (CH++/CH--)
                  </div>
                </div>
              </div>

              {/* OSD Bottom stats */}
              <div className="flex items-center gap-2 mt-auto">
                <div className="osd-overlay px-2.5 py-1.5 flex flex-wrap items-center gap-2 shadow-lg text-[10px]">
                  <span className="font-mono text-white/90">{currentChannel.resolution}</span>
                  <span className="w-1 h-1 rounded-full bg-white/40"></span>
                  <span className="font-mono text-white/90">{currentChannel.frequency}</span>
                </div>
              </div>
            </div>
          </div>

          {/* CONTROL DE AUDIO Y SONIDO CARD */}
          <div className="glass-panel p-4 md:p-5 flex-grow flex flex-col min-h-[250px] lg:min-h-0" id="audio-control-panel">
            <div className="flex items-center gap-2 mb-3 border-b border-surface-variant/40 pb-2 flex-shrink-0">
              <div className="w-8 h-8 rounded-full bg-orange-50 flex items-center justify-center shadow-sm border border-orange-100">
                <span className="material-symbols-outlined text-orange-600 text-sm">volume_up</span>
              </div>
              <div>
                <h3 className="text-sm md:text-base font-bold text-on-surface leading-none">Control de Audio y Sonido</h3>
                <span className="text-[10px] text-outline block mt-0.5">Estado del volumen del amplificador y altavoces</span>
              </div>
            </div>

            <div className="flex flex-row items-stretch gap-3 flex-grow min-h-0">
              
              {/* Audio Waveform and Command lists */}
              <div className="flex-grow flex flex-col justify-between bg-slate-50/50 rounded-xl p-3 border border-surface-variant/40 min-w-0">
                <div className="flex flex-col gap-0.5">
                  <span className="text-[9px] text-outline font-bold uppercase tracking-wider leading-none">Estado de Salida</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className={`w-2 h-2 rounded-full ${isMuted ? "bg-red-500" : "bg-green-500 animate-pulse"}`}></span>
                    <span className="text-xs font-bold text-on-surface">
                      {isMuted ? "Audio Silenciado (MUTE)" : "Salida Activa (ON)"}
                    </span>
                  </div>
                </div>

                {/* Simulated wave bars */}
                <div className="h-14 flex items-center justify-center gap-1 my-2 overflow-hidden">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map((bar) => {
                    const delay = (bar * 0.08).toFixed(2);
                    return (
                      <div
                        key={bar}
                        style={{
                          height: isMuted ? "3px" : "100%",
                          animation: isMuted ? "none" : `wave 1.2s ease-in-out infinite alternate`,
                          animationDelay: `${delay}s`,
                        }}
                        className={`w-1 rounded-full transition-all duration-300 ${
                          isMuted ? "bg-slate-300" : "bg-gradient-to-t from-orange-500 to-amber-500"
                        }`}
                      />
                    );
                  })}
                </div>

                {/* Quick commands guide list */}
                <div className="flex flex-col gap-1 text-[9px] text-outline-variant font-medium mt-1">
                  <div className="flex justify-between border-b border-surface-variant/20 pb-0.5">
                    <span>Subir Vol. (+6%)</span>
                    <span className="font-mono font-bold bg-slate-100 px-1 rounded text-on-surface">Tecla C / 0003#</span>
                  </div>
                  <div className="flex justify-between border-b border-surface-variant/20 pb-0.5">
                    <span>Bajar Vol. (-6%)</span>
                    <span className="font-mono font-bold bg-slate-100 px-1 rounded text-on-surface">Tecla D / 0004#</span>
                  </div>
                  <div className="flex justify-between border-b border-surface-variant/20 pb-0.5">
                    <span>Silenciar</span>
                    <span className="font-mono font-bold bg-slate-100 px-1 rounded text-on-surface">Tecla * / 0005#</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Reactivar</span>
                    <span className="font-mono font-bold bg-slate-100 px-1 rounded text-on-surface">Tecla # / 0006#</span>
                  </div>
                </div>
              </div>

              {/* Slider Track and numeric display */}
              <div className="w-16 md:w-20 bg-slate-50/50 rounded-xl border border-surface-variant/40 flex flex-col items-center py-3 justify-between flex-shrink-0">
                <span className="text-[8px] font-mono font-bold text-outline uppercase tracking-wider">MAX</span>

                <div className="flex-grow py-2 flex flex-col items-center w-full relative">
                  <div className="volume-bar-container w-6 cursor-default">
                    <div 
                      className={`volume-bar-fill w-full ${isMuted ? "bg-slate-300 shadow-none h-0" : ""}`}
                      style={{ height: isMuted ? "0%" : `${volume}%` }}
                    />
                  </div>
                </div>

                <span className="font-mono text-xs md:text-sm font-bold text-on-surface tracking-tight mt-1">
                  {isMuted ? "MUT" : `${volume}%`}
                </span>
                <span className="text-[8px] font-mono font-bold text-outline uppercase tracking-wider mt-1">MIN</span>
              </div>

            </div>
          </div>

        </div>

      </main>

      {/* Footer info line */}
      <footer className="w-full text-center py-2 text-[10px] text-outline mt-3 flex-shrink-0 flex items-center justify-center gap-4">
        <span>Sistema de Interfaz de Laboratorio Transmisor AT v3.2.14</span>
        <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-ping"></span>
        <span>Conexión Activa Segura: Socket FPGA Web</span>
      </footer>

    </div>
  );
}
