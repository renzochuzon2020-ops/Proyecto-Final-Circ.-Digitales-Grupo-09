import serial
import pyautogui
import time

# --- CONFIGURACIÓN ---
PUERTO = 'COM7'
BAUD_RATE = 9600

try:
    arduino = serial.Serial(PUERTO, BAUD_RATE)
    print(f"🟢 Conectado al {PUERTO}.")
    print("¡Haz clic en tu página web de React en los próximos 5 segundos!")
    time.sleep(5)
    print("Escuchando al FPGA...")
except Exception as e:
    print(f"🔴 Error al conectar: {e}")
    exit()

buffer_teclas = ""

while True:
    if arduino.in_waiting > 0:
        letra = arduino.read().decode('ascii', errors='ignore')
        
        # Escribe la letra en la web
        pyautogui.write(letra)
        
        # Filtra saltos de línea y guarda en memoria
        if letra not in ['\r', '\n', ' ']:
            buffer_teclas += letra
            
            # Mantiene solo los últimos 4 números
            if len(buffer_teclas) > 4:
                buffer_teclas = buffer_teclas[-4:]
            
            print(f" Memoria: '{buffer_teclas}'")

            # --- EJECUCIÓN DE COMANDOS ---
            
            # 0003: Subir Volumen
            if buffer_teclas == "0003": 
                print("¡Subiendo volumen (6%)!")
                pyautogui.press('volumeup')
                pyautogui.press('volumeup')
                pyautogui.press('volumeup')
                buffer_teclas = ""
                
            # 0004: Bajar Volumen
            elif buffer_teclas == "0004": 
                print("¡Bajando volumen (6%)!")
                pyautogui.press('volumedown')
                pyautogui.press('volumedown')
                pyautogui.press('volumedown')
                buffer_teclas = ""
                
            # 0005 o 0006: Silenciar / Quitar silencio
            elif buffer_teclas == "0005" or buffer_teclas == "0006":
                print("🔇 ¡Alternando Mute de Windows!")
                pyautogui.press('volumemute')
                buffer_teclas = ""