/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";

interface CommandLog {
  id: string;
  time: string;
  source: "Remote" | "App" | "System" | "User" | "Web API";
  text: string;
  description: string;
  status: "Success" | "Pending" | "Error";
}

interface Channel {
  id: string;
  name: string;
  bgUrl: string;
  resolution: string;
  frequency: string;
}

export default function App() {
  // Live dynamic clock or customized time
  const [time, setTime] = useState<string>("14:23:01");
  const [dateStr, setDateStr] = useState<string>("mar, 24 oct");
  const [isLiveClock, setIsLiveClock] = useState<boolean>(true);

  // Live clock logic
  useEffect(() => {
    if (!isLiveClock) return;
    const updateTime = () => {
      const now = new Date();
      const hrs = String(now.getHours()).padStart(2, "0");
      const mins = String(now.getMinutes()).padStart(2, "0");
      const secs = String(now.getSeconds()).padStart(2, "0");
      setTime(`${hrs}:${mins}:${secs}`);
      
      const options: Intl.DateTimeFormatOptions = { weekday: "short", month: "short", day: "numeric" };
      setDateStr(now.toLocaleDateString("es-ES", options));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [isLiveClock]);

  // Volume control state (0 - 100)
  const [volume, setVolume] = useState<number>(65);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Active television states
  const [currentInput, setCurrentInput] = useState<string>("HDMI 1");
  
  const channelsList: Channel[] = [
    {
      id: "04",
      name: "Red de Noticias Local",
      bgUrl: "https://images.unsplash.com/photo-1585829365295-ab7cd400c167?auto=format&fit=crop&q=80&w=600",
      resolution: "1080p",
      frequency: "60Hz"
    },
    {
      id: "07",
      name: "CineMax Premiere",
      bgUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=600",
      resolution: "4K UHD",
      frequency: "60Hz"
    },
    {
      id: "12",
      name: "Astra Scientific Discovery",
      bgUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=600",
      resolution: "1080p",
      frequency: "120Hz"
    },
    {
      id: "24",
      name: "Radio Retro Soundwave",
      bgUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=600",
      resolution: "720p",
      frequency: "50Hz"
    },
    {
      id: "99",
      name: "Mapa de Diagnóstico de Señal FPGA",
      bgUrl: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&q=80&w=600",
      resolution: "1080p",
      frequency: "144Hz"
    }
  ];

  const [activeChannelIdx, setActiveChannelIdx] = useState<number>(0);
  const currentChannel = channelsList[activeChannelIdx];

  // FPGA Register Bits state (8 bits per register, MSB is index 0)
  const [regPower, setRegPower] = useState<boolean[]>([true, true, true, true, false, false, false, false]); // 0xF0
  const [regDisplay, setRegDisplay] = useState<boolean[]>([true, false, false, false, false, false, false, true]); // 0x81
  const [regData, setRegData] = useState<boolean[]>([true, false, true, false, false, true, false, true]); // 0xA5

  // Navigation or Modal tab states
  const [activeMenuTab, setActiveMenuTab] = useState<"dashboard" | "apps" | "inputs" | "settings">("dashboard");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [customCommandInput, setCustomCommandInput] = useState<string>("");
  const [simulatedSource, setSimulatedSource] = useState<"Remote" | "App" | "System" | "User">("User");

  // Matrix keypad states
  const [keypadBuffer, setKeypadBuffer] = useState<string>("");
  const [pressedKey, setPressedKey] = useState<string | null>(null);

  // Initial command logs history
  const [logs, setLogs] = useState<CommandLog[]>([
    {
      id: "1",
      time: "14:23:01",
      source: "Remote",
      text: "AT+CH=UP",
      description: "Subir Canal",
      status: "Success"
    },
    {
      id: "2",
      time: "14:21:42",
      source: "App",
      text: "AT+VOL=65",
      description: "Volumen establecido a 65%",
      status: "Success"
    },
    {
      id: "3",
      time: "14:15:00",
      source: "System",
      text: "AT+SRC=HDMI1",
      description: "Cambio de Entrada a HDMI 1",
      status: "Success"
    },
    {
      id: "4",
      time: "14:12:10",
      source: "Remote",
      text: "AT+MUTE=ON",
      description: "Silencio Activado",
      status: "Success"
    },
    {
      id: "5",
      time: "14:10:05",
      source: "System",
      text: "AT+BRIGHT=75",
      description: "Nivel de Brillo al 75%",
      status: "Success"
    },
    {
      id: "6",
      time: "13:55:20",
      source: "Remote",
      text: "AT+PIC_MODE=CINEMA",
      description: "Modo de Imagen: Cine",
      status: "Success"
    },
    {
      id: "7",
      time: "13:45:12",
      source: "System",
      text: "AT+SLEEP=60",
      description: "Temporizador de Apagado establecido a 60 min",
      status: "Success"
    },
    {
      id: "8",
      time: "13:30:00",
      source: "Remote",
      text: "AT+CC=ON",
      description: "Subtítulos Activados",
      status: "Success"
    },
    {
      id: "9",
      time: "13:15:45",
      source: "App",
      text: "AT+CAST=START",
      description: "Inicio de Transmisión de Pantalla",
      status: "Pending"
    },
    {
      id: "10",
      time: "13:10:05",
      source: "System",
      text: "AT+PWR=ON",
      description: "Estado de Encendido del Sistema",
      status: "Success"
    }
  ]);

  // Command History Auto-Scroll Ref
  const logsContainerRef = useRef<HTMLDivElement>(null);

  // Helper function: binary array to Hex string
  const bitsToHex = (bits: boolean[]): string => {
    let value = 0;
    bits.forEach((b, i) => {
      if (b) {
        value += Math.pow(2, 7 - i);
      }
    });
    return "0x" + value.toString(16).toUpperCase().padStart(2, "0");
  };

  // Helper function to generate an automated AT command log entry
  const addLog = (text: string, description: string, source: "Remote" | "App" | "System" | "User" | "Web API" = "System") => {
    const now = new Date();
    const formattedTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}`;
    const newEntry: CommandLog = {
      id: String(Date.now()),
      time: formattedTime,
      source,
      text,
      description,
      status: "Success"
    };
    setLogs((prev) => [newEntry, ...prev]);
  };

  // Switch channel trigger
  const handleSelectChannel = (idx: number, triggerSource: "Remote" | "App" | "System" | "User" = "Remote") => {
    setActiveChannelIdx(idx);
    const targetCh = channelsList[idx];
    addLog(`AT+CH=${targetCh.id}`, `Canal establecido a ${targetCh.id} (${targetCh.name})`, triggerSource);
  };

  // Toggle register bits
  const toggleRegBit = (reg: "power" | "display" | "data", bitIndex: number) => {
    let oldHex = "";
    let newHex = "";
    let regName = "";

    if (reg === "power") {
      oldHex = bitsToHex(regPower);
      const updated = [...regPower];
      updated[bitIndex] = !updated[bitIndex];
      setRegPower(updated);
      newHex = bitsToHex(updated);
      regName = "REG_PWR(0xF0)";
    } else if (reg === "display") {
      oldHex = bitsToHex(regDisplay);
      const updated = [...regDisplay];
      updated[bitIndex] = !updated[bitIndex];
      setRegDisplay(updated);
      newHex = bitsToHex(updated);
      regName = "REG_DISP(0x01)";
    } else {
      oldHex = bitsToHex(regData);
      const updated = [...regData];
      updated[bitIndex] = !updated[bitIndex];
      setRegData(updated);
      newHex = bitsToHex(updated);
      regName = "REG_DATA(0xA5)";
    }

    addLog(
      `AT+WRITE=${reg === "power" ? "0xF0" : reg === "display" ? "0x01" : "0xA5"},${newHex}`,
      `Bit ${7 - bitIndex} de FPGA ${regName} alternado (${oldHex} ➔ ${newHex})`,
      "System"
    );
  };

  // Volume handlers
  const handleVolumeChange = (newVal: number) => {
    if (newVal < 0) newVal = 0;
    if (newVal > 100) newVal = 100;
    setVolume(newVal);
    if (isMuted && newVal > 0) {
      setIsMuted(false);
    }
  };

  const logVolumeAction = (val: number) => {
    addLog(`AT+VOL=${val}`, `Volumen establecido al ${val}%`, "Remote");
  };

  const handleMuteToggle = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    addLog(`AT+MUTE=${nextMute ? "ON" : "OFF"}`, `Salida de audio ${nextMute ? "Silenciada" : "Reactivada"}`, "Remote");
  };

  // Form custom AT commands submit
  const handleSendCustomCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customCommandInput.trim()) return;
    const cleanCmd = customCommandInput.trim().toUpperCase();
    
    // Simple command interpreter for interactive mock fun
    let interpretation = "Ejecución de comando de usuario personalizado";
    if (cleanCmd.startsWith("AT+VOL=")) {
      const v = parseInt(cleanCmd.replace("AT+VOL=", ""));
      if (!isNaN(v)) {
        handleVolumeChange(v);
        interpretation = `Establecer volumen al ${v}%`;
      }
    } else if (cleanCmd === "AT+CH=UP") {
      const nextIdx = (activeChannelIdx + 1) % channelsList.length;
      setActiveChannelIdx(nextIdx);
      interpretation = `Subir canal a ${channelsList[nextIdx].name}`;
    } else if (cleanCmd === "AT+CH=DOWN") {
      const prevIdx = (activeChannelIdx - 1 + channelsList.length) % channelsList.length;
      setActiveChannelIdx(prevIdx);
      interpretation = `Bajar canal a ${channelsList[prevIdx].name}`;
    } else if (cleanCmd.startsWith("AT+SRC=")) {
      const src = cleanCmd.replace("AT+SRC=", "");
      setCurrentInput(src);
      interpretation = `Cambio de fuente de entrada a ${src}`;
    } else if (cleanCmd === "AT+MUTE=ON") {
      setIsMuted(true);
      interpretation = "Silencio ACTIVADO";
    } else if (cleanCmd === "AT+MUTE=OFF") {
      setIsMuted(false);
      interpretation = "Silencio DESACTIVADO";
    } else if (cleanCmd === "AT+CLEAR") {
      setLogs([]);
      setCustomCommandInput("");
      return;
    } else if (cleanCmd === "AT+RESET") {
      setRegPower([true, true, true, true, false, false, false, false]);
      setRegDisplay([true, false, false, false, false, false, false, true]);
      setRegData([true, false, true, false, false, true, false, true]);
      setVolume(65);
      setIsMuted(false);
      setActiveChannelIdx(0);
      setCurrentInput("HDMI 1");
      setLogs([]);
      addLog("AT+RESET", "Configuración del sistema restaurada a los valores de fábrica predeterminados", "System");
      setCustomCommandInput("");
      return;
    }

    addLog(cleanCmd, interpretation, simulatedSource);
    setCustomCommandInput("");
  };

  // Matrix keypad controllers for PHYSICAL KEYPAD emulator (uses keyboard event listeners on PC to test)
  const handleKeyPress = (key: string) => {
    // Visual feedback
    setPressedKey(key);
    setTimeout(() => setPressedKey(null), 150);

    if (key === "#") {
      if (keypadBuffer.length === 4) {
        evaluateBuffer(keypadBuffer);
        setKeypadBuffer("");
      } else if (keypadBuffer.length > 0) {
        addLog("AT+ERR", `Error: Código incompleto '${keypadBuffer}'. Se requieren exactamente 4 dígitos.`, "User");
        setKeypadBuffer("");
      }
    } else if (key === "*") {
      setKeypadBuffer("");
      addLog("AT+CLEAR", "Teclado: Marcación cancelada / Buffer de sintonización limpio", "User");
    } else {
      // Accumulate standard characters/digits (0-9, A-D)
      if (keypadBuffer.length < 4) {
        const nextBuf = keypadBuffer + key;
        setKeypadBuffer(nextBuf);

        // Auto-execute if exact 4 digits are dialed
        if (nextBuf.length === 4) {
          setTimeout(() => {
            evaluateBuffer(nextBuf);
            setKeypadBuffer("");
          }, 350);
        }
      }
    }
  };

  const evaluateBuffer = (buf: string) => {
    const cleanBuf = buf.trim();

    // Check register toggle codes for Power: 0040 to 0047
    if (cleanBuf.startsWith("004") && cleanBuf.length === 4) {
      const bitVal = parseInt(cleanBuf.charAt(3), 10);
      if (bitVal >= 0 && bitVal <= 7) {
        const actualIdx = 7 - bitVal; // MSB is index 0
        const updated = [...regPower];
        updated[actualIdx] = !updated[updated[actualIdx] ? actualIdx : actualIdx]; // standard logical toggle
        updated[actualIdx] = !regPower[actualIdx];
        setRegPower(updated);
        addLog(`AT+WRITE=0xF0,${bitsToHex(updated)}`, `Teclado '004${bitVal}#': Alternar Bit ${bitVal} de Registro Power`, "User");
        return;
      }
    }

    // Check register toggle codes for Display: 0050 to 0057
    if (cleanBuf.startsWith("005") && cleanBuf.length === 4) {
      const bitVal = parseInt(cleanBuf.charAt(3), 10);
      if (bitVal >= 0 && bitVal <= 7) {
        const actualIdx = 7 - bitVal;
        const updated = [...regDisplay];
        updated[actualIdx] = !regDisplay[actualIdx];
        setRegDisplay(updated);
        addLog(`AT+WRITE=0x01,${bitsToHex(updated)}`, `Teclado '005${bitVal}#': Alternar Bit ${bitVal} de Registro Display`, "User");
        return;
      }
    }

    // Check register toggle codes for Data Stream: 0060 to 0067
    if (cleanBuf.startsWith("006") && cleanBuf.length === 4) {
      const bitVal = parseInt(cleanBuf.charAt(3), 10);
      if (bitVal >= 0 && bitVal <= 7) {
        const actualIdx = 7 - bitVal;
        const updated = [...regData];
        updated[actualIdx] = !regData[actualIdx];
        setRegData(updated);
        addLog(`AT+WRITE=0xA5,${bitsToHex(updated)}`, `Teclado '006${bitVal}#': Alternar Bit ${bitVal} de Registro Data`, "User");
        return;
      }
    }

    // Switch for predefined 4-digit commands
    switch (cleanBuf) {
      case "0000":
        setRegPower([true, true, true, true, false, false, false, false]);
        setRegDisplay([true, false, false, false, false, false, false, true]);
        setRegData([true, false, true, false, false, true, false, true]);
        setVolume(65);
        setIsMuted(false);
        setActiveChannelIdx(0);
        setCurrentInput("HDMI 1");
        setLogs([]);
        addLog("AT+RESET", "Teclado '0000#': Restablecer Fábrica (RESET)", "User");
        break;
      case "0001": {
        const nextIdx = (activeChannelIdx + 1) % channelsList.length;
        setActiveChannelIdx(nextIdx);
        addLog("AT+0001", "Teclado '0001#': Siguiente Canal (CH++)", "User");
        break;
      }
      case "0002": {
        const prevIdx = (activeChannelIdx - 1 + channelsList.length) % channelsList.length;
        setActiveChannelIdx(prevIdx);
        addLog("AT+0002", "Teclado '0002#': Canal Anterior (CH--)", "User");
        break;
      }
      case "0003": {
        const nextVol = Math.min(volume + 5, 100);
        handleVolumeChange(nextVol);
        addLog("AT+0003", `Teclado '0003#': Volumen incrementado a ${nextVol}%`, "User");
        break;
      }
      case "0004": {
        const prevVol = Math.max(volume - 5, 0);
        handleVolumeChange(prevVol);
        addLog("AT+0004", `Teclado '0004#': Volumen disminuido a ${prevVol}%`, "User");
        break;
      }
      case "0005":
        setIsMuted(true);
        addLog("AT+0005", "Teclado '0005#': Audio Silenciado (MUTE ON)", "User");
        break;
      case "0006":
        setIsMuted(false);
        addLog("AT+0006", "Teclado '0006#': Audio Reactivado (MUTE OFF)", "User");
        break;
      case "0011":
        setActiveChannelIdx(0);
        addLog("AT+0011", "Teclado '0011#': Selección Canal 1 (CH04)", "User");
        break;
      case "0012":
        setActiveChannelIdx(1);
        addLog("AT+0012", "Teclado '0012#': Selección Canal 2 (CH07)", "User");
        break;
      case "0013":
        setActiveChannelIdx(2);
        addLog("AT+0013", "Teclado '0013#': Selección Canal 3 (CH12)", "User");
        break;
      case "0014":
        setActiveChannelIdx(3);
        addLog("AT+0014", "Teclado '0014#': Selección Canal 4 (CH24)", "User");
        break;
      case "0015":
        setActiveChannelIdx(4);
        addLog("AT+0015", "Teclado '0015#': Selección Canal 5 (CH99)", "User");
        break;
      case "0021":
        setCurrentInput("HDMI 1");
        addLog("AT+0021", "Teclado '0021#': Entrada establecida a HDMI 1", "User");
        break;
      case "0022":
        setCurrentInput("HDMI 2");
        addLog("AT+0022", "Teclado '0022#': Entrada establecida a HDMI 2", "User");
        break;
      case "0023":
        setCurrentInput("DisplayPort");
        addLog("AT+0023", "Teclado '0023#': Entrada establecida a DisplayPort", "User");
        break;
      case "0024":
        setCurrentInput("AV Component");
        addLog("AT+0024", "Teclado '0024#': Entrada establecida a AV Component", "User");
        break;
      case "0025":
        setCurrentInput("S-Video");
        addLog("AT+0025", "Teclado '0025#': Entrada establecida a S-Video", "User");
        break;
      case "0026":
        setCurrentInput("OTA Antenna");
        addLog("AT+0026", "Teclado '0026#': Entrada establecida a OTA Antenna", "User");
        break;
      case "0031":
        handleLaunchApp("Netflix", "from-red-500 to-red-700");
        addLog("AT+0031", "Teclado '0031#': Aplicación Netflix Iniciada", "User");
        break;
      case "0032":
        handleLaunchApp("Spotify", "from-green-500 to-green-700");
        addLog("AT+0032", "Teclado '0032#': Aplicación Spotify Iniciada", "User");
        break;
      case "0033":
        handleLaunchApp("YouTube", "from-red-600 to-red-800");
        addLog("AT+0033", "Teclado '0033#': Aplicación YouTube Iniciada", "User");
        break;
      case "0034":
        handleLaunchApp("Prime Video", "from-blue-400 to-blue-600");
        addLog("AT+0034", "Teclado '0034#': Aplicación Prime Video Iniciada", "User");
        break;
      case "0035":
        handleLaunchApp("Disney+", "from-blue-600 to-blue-900");
        addLog("AT+0035", "Teclado '0035#': Aplicación Disney+ Iniciada", "User");
        break;
      case "0036":
        handleLaunchApp("Cable TV", "from-gray-500 to-gray-700");
        addLog("AT+0036", "Teclado '0036#': Aplicación Cable TV Iniciada", "User");
        break;
      case "0099":
        setRegPower([true, true, true, true, true, true, true, true]);
        addLog("AT+WRITE=0xF0,0xFF", "Teclado '0099#': REG Power sobrescrito a nivel alto (0xFF)", "User");
        break;
      default:
        addLog(`AT+ERR`, `Teclado: Secuencia inválida '${cleanBuf}#'`, "User");
        break;
    }
  };

  // Keyboard matrix system listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid capturing keystrokes when user is active in default browser inputs
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === "INPUT" || activeEl.tagName === "TEXTAREA" || activeEl.tagName === "SELECT")) {
        return;
      }

      let key = e.key.toUpperCase();
      if (e.key === "Enter") key = "#";
      if (e.key === "Backspace" || e.key === "Escape") key = "*";

      const validKeys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "A", "B", "C", "D", "*", "#"];
      if (validKeys.includes(key)) {
        e.preventDefault();
        handleKeyPress(key);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [keypadBuffer, activeChannelIdx, volume, isMuted, currentInput, regPower, regDisplay, regData]);

  // Launch pre-built recommended apps
  const handleLaunchApp = (appName: string, themeColor: string) => {
    addLog(`AT+LAUNCH=${appName.toUpperCase()}`, `Iniciando aplicación ${appName}`, "App");
    
    // Switch channel to represent the playing app on OSD dynamically
    if (appName === "YouTube") {
      handleSelectChannel(3, "App"); // Radio / stream
    } else if (appName === "Spotify") {
      handleSelectChannel(3, "App"); 
    } else if (appName === "Netflix") {
      handleSelectChannel(1, "App"); // CineMax
    } else if (appName === "Disney+") {
      handleSelectChannel(2, "App"); // Astro Scientific
    } else if (appName === "Cable TV") {
      handleSelectChannel(0, "App"); // Local News
    }
  };

  // Filter commands log list
  const filteredLogs = logs.filter((log) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      log.text.toLowerCase().includes(searchLower) ||
      log.description.toLowerCase().includes(searchLower) ||
      log.source.toLowerCase().includes(searchLower)
    );
  });

  return (
    <div className="min-h-screen w-full flex flex-col font-sans text-on-surface-variant relative p-2 md:p-4 bg-surface selection:bg-primary-fixed select-none">
      
      {/* Ambient background decorative nodes */}
      <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden bg-yellow-50/15">
        <div className="absolute top-[-10%] left-[-5%] w-[45vw] h-[45vw] rounded-full bg-blue-200/20 blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-5%] w-[55vw] h-[55vw] rounded-full bg-teal-100/20 blur-[140px]"></div>
        <div className="absolute top-[20%] right-[15%] w-[35vw] h-[35vw] rounded-full bg-purple-100/15 blur-[100px]"></div>
      </div>

      <main className="flex-grow w-full max-w-7xl mx-auto grid grid-cols-12 gap-3 md:gap-4 relative z-10 min-h-0">
        
        {/* ========================================================= */}
        {/* LEFT COLUMN: NAVIGATION, RECOMMENDED APPS & AT LOG HISTORY */}
        {/* ========================================================= */}
        <div className="col-span-12 lg:col-span-8 flex flex-col gap-3 md:gap-4 min-h-0">
          
          {/* TOP INSTRUMENT CONTROL NAVIGATION */}
          <div className="glass-panel p-3.5 flex flex-wrap items-center justify-between gap-4 flex-shrink-0" id="header-nav-bar">
            <div className="flex items-center gap-3">
              <div 
                className="flex items-center gap-2.5 cursor-pointer hover:opacity-80 transition-all"
                onClick={() => {
                  addLog("AT+SYS=STATUS", "Solicitud de verificación de estado de Transmisor AT - PQT App", "User");
                }}
              >
                <span className="material-symbols-outlined text-primary-container fill-1 animate-pulse text-2xl md:text-3xl">smart_display</span>
                <div className="flex flex-col justify-center select-none">
                  <span className="bg-gradient-to-r from-primary to-primary-container bg-clip-text text-transparent font-black text-sm md:text-base leading-none tracking-tight">Transmisor AT</span>
                  <span className="text-[10px] md:text-[11px] font-bold text-outline leading-none mt-0.5 tracking-wider">PQT App</span>
                </div>
              </div>
              <div className="h-5 w-px bg-surface-variant hidden sm:block"></div>
              
              {/* Tabs Menu buttons with dynamic active styles */}
              <div className="flex gap-1.5 overflow-x-auto py-0.5 scrollbar-none">
                <button 
                  onClick={() => {
                    setActiveMenuTab("dashboard");
                    addLog("AT+TAB=DASHBOARD", "Navegación a la vista del panel principal", "User");
                  }}
                  className={`app-icon flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    activeMenuTab === "dashboard" 
                      ? "bg-primary text-white shadow-md shadow-primary/20" 
                      : "bg-surface-container-low hover:bg-surface-container-high text-on-surface"
                  }`}
                  id="tab-dashboard"
                >
                  <span className="material-symbols-outlined text-sm">space_dashboard</span>
                  <span>Panel Control</span>
                </button>
 
                <button 
                  onClick={() => {
                    setActiveMenuTab("apps");
                    addLog("AT+TAB=APPS", "Navegación a la lista de aplicaciones recomendadas", "User");
                  }}
                  className={`app-icon flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    activeMenuTab === "apps" 
                      ? "bg-primary text-white shadow-md shadow-primary/20" 
                      : "bg-surface-container-low hover:bg-surface-container-high text-on-surface"
                  }`}
                  id="tab-apps"
                >
                  <span className="material-symbols-outlined text-sm font-bold">apps</span>
                  <span>Aplicaciones</span>
                </button>
 
                <button 
                  onClick={() => {
                    setActiveMenuTab("inputs");
                    addLog("AT+TAB=INPUTS", "Consulta de la lista de entradas activas de telemetría", "User");
                  }}
                  className={`app-icon flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    activeMenuTab === "inputs" 
                      ? "bg-primary text-white shadow-md shadow-primary/20" 
                      : "bg-surface-container-low hover:bg-surface-container-high text-on-surface"
                  }`}
                  id="tab-inputs"
                >
                  <span className="material-symbols-outlined text-sm">input</span>
                  <span>Entradas</span>
                </button>
 
                <button 
                  onClick={() => {
                    setActiveMenuTab("settings");
                    addLog("AT+TAB=SETTINGS", "Navegación a las configuraciones del sistema", "User");
                  }}
                  className={`app-icon flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    activeMenuTab === "settings" 
                      ? "bg-primary text-white shadow-md shadow-primary/20" 
                      : "bg-surface-container-low hover:bg-surface-container-high text-on-surface"
                  }`}
                  id="tab-settings"
                >
                  <span className="material-symbols-outlined text-sm">settings</span>
                  <span>Ajustes</span>
                </button>
              </div>
            </div>
 
            {/* Live Clock & Profiles Section */}
            <div className="flex items-center gap-3.5 ml-auto sm:ml-0">
              <div 
                className="text-center cursor-pointer group"
                onClick={() => {
                  setIsLiveClock(!isLiveClock);
                  addLog(
                    isLiveClock ? "AT+CLK=STATIC" : "AT+CLK=LIVE", 
                    isLiveClock ? "Reloj configurado en congelamiento estático manual" : "Sincronizando reloj UTC del sistema en vivo", 
                    "System"
                  );
                }}
                title={isLiveClock ? "Clic para congelar el reloj" : "Clic para sincronizar hora UTC en vivo"}
              >
                <div className="font-bold text-on-surface text-sm font-mono tracking-wider flex items-center gap-1 justify-center">
                  <span className={`w-1.5 h-1.5 rounded-full ${isLiveClock ? "bg-green-500 animate-ping" : "bg-orange-400"}`}></span>
                  {time}
                </div>
                <div className="text-[10px] text-outline font-semibold tracking-wide transition-colors group-hover:text-primary">
                  {dateStr} {!isLiveClock && "(Congelado)"}
                </div>
              </div>
              
              <button 
                onClick={() => {
                  addLog("AT+USER=INFO", "Solicitud de verificación de metadatos del perfil de usuario", "User");
                  alert("Sesión iniciada como Andrea Rodriguez - Perfil de Desarrollador de Transmisor AT verificado.");
                }}
                className="w-8 h-8 rounded-full bg-purple-100/90 shadow-sm flex items-center justify-center text-purple-700 hover:bg-purple-200 transition-colors cursor-pointer border border-purple-200/40"
                title="Ver credenciales de usuario"
                id="profile-avatar-btn"
              >
                <span className="material-symbols-outlined text-[16px] font-bold">person</span>
              </button>
            </div>
          </div>

          {/* DYNAMIC MIDDLE CONTROLLER MAIN PANEL */}
          {activeMenuTab === "dashboard" && (
            <div className="glass-panel p-4 flex flex-col justify-between flex-shrink-0" id="apps-recommended-container">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-headline-md text-base md:text-lg text-on-surface flex items-center gap-2">
                  <span className="material-symbols-outlined text-orange-500 text-[18px]">grid_view</span>
                  <span>Aplicaciones del Sistema</span>
                </h3>
                <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                  Bloqueado (Solo FPGA)
                </span>
              </div>
              
              <div className="flex gap-3 overflow-x-auto pb-1.5 custom-scrollbar" id="apps-scrollable-row">
                <div 
                  className="app-icon min-w-[100px] flex-1 bg-gradient-to-br from-red-500/80 to-red-700/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 opacity-90 cursor-default shadow"
                  id="app-netflix"
                  title="Controlado mediante teclado físico"
                >
                  <span className="material-symbols-outlined text-2xl">play_circle</span>
                  <span className="text-[11px] font-bold tracking-wide">Netflix</span>
                </div>
                
                <div 
                  className="app-icon min-w-[100px] flex-1 bg-gradient-to-br from-green-500/80 to-green-700/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 opacity-90 cursor-default shadow"
                  id="app-spotify"
                  title="Controlado mediante teclado físico"
                >
                  <span className="material-symbols-outlined text-2xl">music_note</span>
                  <span className="text-[11px] font-bold tracking-wide">Spotify</span>
                </div>
 
                <div 
                  className="app-icon min-w-[100px] flex-1 bg-gradient-to-br from-red-600/80 to-red-800/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 opacity-90 cursor-default shadow"
                  id="app-youtube"
                  title="Controlado mediante teclado físico"
                >
                  <span className="material-symbols-outlined text-2xl">smart_display</span>
                  <span className="text-[11px] font-bold tracking-wide">YouTube</span>
                </div>
 
                <div 
                  className="app-icon min-w-[100px] flex-1 bg-gradient-to-br from-blue-400/80 to-blue-600/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 opacity-90 cursor-default shadow"
                  id="app-prime"
                  title="Controlado mediante teclado físico"
                >
                  <span className="material-symbols-outlined text-2xl">shopping_bag</span>
                  <span className="text-[11px] font-bold tracking-wide">Prime Video</span>
                </div>
 
                <div 
                  className="app-icon min-w-[100px] flex-1 bg-gradient-to-br from-blue-600/80 to-blue-900/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 opacity-90 cursor-default shadow"
                  id="app-disney"
                  title="Controlado mediante teclado físico"
                >
                  <span className="material-symbols-outlined text-2xl">movie</span>
                  <span className="text-[11px] font-bold tracking-wide">Disney+</span>
                </div>
 
                <div 
                  className="app-icon min-w-[100px] flex-1 bg-gradient-to-br from-gray-500/80 to-gray-700/80 rounded-xl p-3 text-white flex flex-col items-center justify-center gap-1.5 opacity-90 cursor-default shadow"
                  id="app-cable"
                  title="Controlado mediante teclado físico"
                >
                  <span className="material-symbols-outlined text-2xl">settings_input_antenna</span>
                  <span className="text-[11px] font-bold tracking-wide">Cable TV</span>
                </div>
              </div>
            </div>
          )}

          {/* TABS SUB-PAGES ACCORDING TO NAVIGATION */}
          {activeMenuTab === "apps" && (
            <div className="glass-panel p-4 flex flex-col gap-3 flex-shrink-0 animate-fadeIn" id="app-expanded-directory">
              <div className="flex justify-between items-center border-b border-surface-variant pb-2">
                <h3 className="font-headline-md text-base text-on-surface flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">apps_outage</span>
                  <span>Directorio de Aplicaciones del Sistema</span>
                </h3>
                <button 
                  onClick={() => {
                    setActiveMenuTab("dashboard");
                  }}
                  className="text-xs text-primary font-bold hover:underline"
                >
                  Volver al Panel Control
                </button>
              </div>
              <p className="text-xs text-outline">
                Directorio de aplicaciones integradas. El control y lanzamiento de las mismas se efectúa exclusivamente mediante el teclado matricial físico.
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { name: "Netflix", category: "Entretenimiento", icon: "movie", color: "from-red-600 to-red-800" },
                  { name: "Spotify", category: "Música en Streaming", icon: "music_note", color: "from-green-600 to-green-800" },
                  { name: "YouTube", category: "Red de Video", icon: "video_library", color: "from-red-500 to-orange-600" },
                  { name: "Disney+", category: "Cine en Casa", icon: "theater_comedy", color: "from-indigo-600 to-blue-800" },
                  { name: "TV de Diagnóstico", category: "Diagnósticos", icon: "troubleshoot", color: "from-teal-600 to-teal-800" },
                  { name: "Audio FPGA", category: "Sintetizador de Hardware", icon: "audio_file", color: "from-purple-600 to-pink-800" },
                  { name: "Navegador Web", category: "Navegador", icon: "language", color: "from-blue-500 to-indigo-600" },
                  { name: "Consola de Ajustes", category: "Parámetros", icon: "settings", color: "from-slate-600 to-slate-800" }
                ].map((a, i) => (
                  <div 
                    key={i}
                    className="app-icon p-3 rounded-xl bg-surface-container border border-white/80 flex flex-col items-center text-center gap-1 cursor-default"
                    title="Controlado mediante teclado físico"
                  >
                    <div className={`w-8 h-8 rounded-full bg-gradient-to-tr ${a.color} flex items-center justify-center text-white text-xs mb-1`}>
                      <span className="material-symbols-outlined text-[16px]">{a.icon}</span>
                    </div>
                    <span className="font-bold text-xs text-on-surface block">{a.name}</span>
                    <span className="text-[9px] text-outline block">{a.category}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeMenuTab === "inputs" && (
            <div className="glass-panel p-4 flex flex-col gap-3 flex-shrink-0 animate-fadeIn" id="inputs-expanded-directory">
              <div className="flex justify-between items-center border-b border-surface-variant pb-2">
                <h3 className="font-headline-md text-base text-on-surface flex items-center gap-2">
                  <span className="material-symbols-outlined text-secondary">input_circle</span>
                  <span>Fuentes de Entrada de Señal FPGA</span>
                </h3>
                <button 
                  onClick={() => setActiveMenuTab("dashboard")}
                  className="text-xs text-primary font-bold hover:underline"
                >
                  Volver al Panel Control
                </button>
              </div>
              <p className="text-xs text-outline">
                Canales y puertos mapeados en el demultiplexor FPGA. Utilice el teclado matricial físico (combinaciones 6#, 7#, 8#) para modificar la entrada activa.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: "HDMI 1", label: "Receptor Multimedia", desc: "Decodificador local principal", icon: "settings_input_hdmi", activeColor: "border-blue-500 bg-blue-50/50 text-blue-700" },
                  { id: "HDMI 2", label: "Laptop de Desarrollo", desc: "Estación de trabajo", icon: "laptop_mac", activeColor: "border-purple-500 bg-purple-50/50 text-purple-700" },
                  { id: "AV Component", label: "Consola Heredada", desc: "Entrada analógica", icon: "settings_input_component", activeColor: "border-orange-500 bg-orange-50/50 text-orange-700" },
                  { id: "DisplayPort", label: "Sintetizador FPGA", desc: "Forma de onda digital", icon: "cable", activeColor: "border-teal-500 bg-teal-50/50 text-teal-700" },
                  { id: "S-Video", label: "Diagnóstico de Laboratorio", desc: "Sincronización entrelazada", icon: "terminal", activeColor: "border-pink-500 bg-pink-50/50 text-pink-700" },
                  { id: "OTA Antenna", label: "RF Terrestre", desc: "Sintonizador ATSC", icon: "cell_tower", activeColor: "border-amber-500 bg-amber-50/50 text-amber-700" }
                ].map((inp) => (
                  <div 
                    key={inp.id}
                    className={`p-3 rounded-xl border transition-all cursor-default flex items-center gap-3 ${
                      currentInput === inp.id 
                        ? `${inp.activeColor} border-2 font-bold shadow-sm` 
                        : "border-surface-variant bg-white/40 opacity-70"
                    }`}
                    title="Controlado mediante teclado físico"
                  >
                    <span className="material-symbols-outlined text-lg">{inp.icon}</span>
                    <div>
                      <div className="text-xs font-bold text-on-surface">{inp.id}</div>
                      <div className="text-[10px] text-outline">{inp.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeMenuTab === "settings" && (
            <div className="glass-panel p-4 flex flex-col gap-3 flex-shrink-0 animate-fadeIn" id="settings-expanded-directory">
              <div className="flex justify-between items-center border-b border-surface-variant pb-2">
                <h3 className="font-headline-md text-base text-on-surface flex items-center gap-2">
                  <span className="material-symbols-outlined text-purple-600">settings</span>
                  <span>Panel de Control de Configuración de FPGA y Sistema</span>
                </h3>
                <button 
                  onClick={() => setActiveMenuTab("dashboard")}
                  className="text-xs text-primary font-bold hover:underline"
                >
                  Volver al Panel Control
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-50/50 p-3 rounded-xl border border-surface-variant flex flex-col gap-2 opacity-85">
                  <h4 className="text-xs font-bold text-on-surface flex items-center gap-1">
                    <span className="material-symbols-outlined text-xs text-red-500">lock</span>
                    Opciones de Reinicio de Hardware
                  </h4>
                  <p className="text-[10px] text-outline">
                    Para reiniciar registros FPGA, estado de volumen y base de datos, use el comando AT correspondiente desde su teclado físico.
                  </p>
                  <button 
                    disabled
                    className="mt-1 bg-slate-200 text-slate-500 text-xs font-bold py-1.5 px-3 rounded-lg cursor-not-allowed self-start flex items-center gap-1.5"
                  >
                    <span className="material-symbols-outlined text-[12px]">block</span>
                    Restablecimiento Completo de Fábrica (Solo Comando 0000#)
                  </button>
                </div>

                <div className="bg-slate-50/50 p-3 rounded-xl border border-surface-variant flex flex-col gap-2 opacity-85">
                  <h4 className="text-xs font-bold text-on-surface flex items-center gap-1">
                    <span className="material-symbols-outlined text-xs text-purple-500">lock</span>
                    Registros de Telemetría del Desarrollador
                  </h4>
                  <p className="text-[10px] text-outline">
                    Para limpiar las tablas de logs o pre-cargar diagnósticos, envíe las secuencias correctas mediante su hardware matricial.
                  </p>
                  <div className="flex gap-2">
                    <button 
                      disabled
                      className="bg-slate-200 text-slate-500 text-xs font-bold py-1.5 px-3 rounded-lg cursor-not-allowed flex items-center gap-1"
                    >
                      <span className="material-symbols-outlined text-[12px]">block</span>
                      Limpiar Logs (Comando 0000#)
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* GUÍA Y DIRECTORIO DE COMANDOS AT (4 DÍGITOS) */}
          <div className="glass-panel p-4 md:p-5 flex flex-col flex-grow min-h-[400px] lg:min-h-0" id="command-directory-container">
            {/* Header section with controllers */}
            <div className="flex flex-wrap items-center justify-between gap-3 mb-3.5 flex-shrink-0 border-b border-surface-variant/40 pb-3">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-green-600 bg-green-50 p-1.5 rounded-lg shadow-sm text-sm font-bold">menu_book</span>
                <div>
                  <h3 className="font-headline-md text-base md:text-lg text-on-surface font-semibold tracking-tight">
                    Directorio de Comandos AT (Teclado Físico)
                  </h3>
                  <p className="text-[11px] text-outline">
                    Marca 4 dígitos en tu teclado o haz clic en cualquier comando para ejecutarlo.
                  </p>
                </div>
              </div>
              
              {/* LED-Style Digital Keypad Buffer Display */}
              <div className="flex items-center gap-2 bg-slate-950 text-slate-100 p-2 rounded-xl border border-slate-800 shadow-inner">
                <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Marcado:</span>
                <div className="flex gap-1">
                  {[0, 1, 2, 3].map((idx) => {
                    const char = keypadBuffer[idx] || "";
                    return (
                      <span 
                        key={idx} 
                        className={`w-6 h-7 rounded bg-slate-900 border border-slate-800 flex items-center justify-center font-mono font-bold text-xs ${
                          char ? "text-yellow-400 animate-pulse" : "text-slate-600"
                        }`}
                      >
                        {char || "_"}
                      </span>
                    );
                  })}
                </div>
                <span className="text-[9px] text-green-400 font-mono animate-pulse font-bold">
                  {keypadBuffer.length === 4 ? "OK" : "..."}
                </span>
              </div>
            </div>

            {/* SCROLLABLE GRID OF ALL COMMANDS */}
            <div className="overflow-y-auto pr-1.5 custom-scrollbar flex-grow space-y-4 max-h-[450px] lg:max-h-[380px]">
              {/* CATEGORY 1: TUNER & CHANNELS */}
              <div>
                <h4 className="text-xs font-bold text-on-surface flex items-center gap-1 mb-2 sticky top-0 bg-white/90 backdrop-blur-sm py-1 z-10">
                  <span className="material-symbols-outlined text-xs text-blue-500">settings_input_antenna</span>
                  Sintonizador de Canales (Tuner Control)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {[
                    { code: "0001", label: "Siguiente Canal (CH++)", desc: "Avanza al próximo canal en la lista de sintonización" },
                    { code: "0002", label: "Canal Anterior (CH--)", desc: "Retrocede al canal anterior en la lista de sintonización" },
                    { code: "0011", label: "Seleccionar Canal 1 (CH04)", desc: "Sintoniza directamente el canal Local News Network" },
                    { code: "0012", label: "Seleccionar Canal 2 (CH07)", desc: "Sintoniza directamente el canal CineMax Premiere" },
                    { code: "0013", label: "Seleccionar Canal 3 (CH12)", desc: "Sintoniza directamente el canal Astra Scientific Discovery" },
                    { code: "0014", label: "Seleccionar Canal 4 (CH24)", desc: "Sintoniza directamente el canal Retro Soundwave Radio" },
                    { code: "0015", label: "Seleccionar Canal 5 (CH99)", desc: "Sintoniza directamente el canal FPGA Signal Diagnostic Map" },
                  ].map((cmd) => (
                    <button
                      key={cmd.code}
                      onClick={() => evaluateBuffer(cmd.code)}
                      className="flex items-center justify-between p-2 rounded-xl border border-surface-variant bg-white/50 hover:bg-primary/5 hover:border-primary transition-all text-left group"
                    >
                      <div className="flex flex-col gap-0.5">
                        <span className="font-bold text-[11px] text-on-surface group-hover:text-primary transition-colors">{cmd.label}</span>
                        <span className="text-[10px] text-outline-variant line-clamp-1">{cmd.desc}</span>
                      </div>
                      <span className="font-mono text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-100 px-2 py-0.5 rounded shadow-sm group-hover:bg-primary group-hover:text-white transition-all">
                        {cmd.code}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* CATEGORY 2: AUDIO CONTROL */}
              <div>
                <h4 className="text-xs font-bold text-on-surface flex items-center gap-1 mb-2 sticky top-0 bg-white/90 backdrop-blur-sm py-1 z-10">
                  <span className="material-symbols-outlined text-xs text-orange-500">volume_up</span>
                  Control de Audio (Sound Controls)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {[
                    { code: "0003", label: "Incrementar Volumen +5%", desc: "Aumenta el nivel de ganancia de audio de la placa" },
                    { code: "0004", label: "Disminuir Volumen -5%", desc: "Disminuye el nivel de ganancia de audio de la placa" },
                    { code: "0005", label: "Silenciar Audio (Mute)", desc: "Corta la salida analógica del amplificador de la placa" },
                    { code: "0006", label: "Reactivar Audio (Unmute)", desc: "Restaura la ganancia del amplificador de audio de la placa" },
                  ].map((cmd) => (
                    <button
                      key={cmd.code}
                      onClick={() => evaluateBuffer(cmd.code)}
                      className="flex items-center justify-between p-2 rounded-xl border border-surface-variant bg-white/50 hover:bg-primary/5 hover:border-primary transition-all text-left group"
                    >
                      <div className="flex flex-col gap-0.5">
                        <span className="font-bold text-[11px] text-on-surface group-hover:text-primary transition-colors">{cmd.label}</span>
                        <span className="text-[10px] text-outline-variant line-clamp-1">{cmd.desc}</span>
                      </div>
                      <span className="font-mono text-[10px] font-bold bg-orange-50 text-orange-700 border border-orange-100 px-2 py-0.5 rounded shadow-sm group-hover:bg-primary group-hover:text-white transition-all">
                        {cmd.code}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* CATEGORY 3: INPUT SOURCES MULTIPLEXER */}
              <div>
                <h4 className="text-xs font-bold text-on-surface flex items-center gap-1 mb-2 sticky top-0 bg-white/90 backdrop-blur-sm py-1 z-10">
                  <span className="material-symbols-outlined text-xs text-teal-500">settings_input_hdmi</span>
                  Mapeo de Entradas (FPGA Demux Input)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {[
                    { code: "0021", label: "Entrada HDMI 1", desc: "Mapea la salida hacia la workstation local principal" },
                    { code: "0022", label: "Entrada HDMI 2", desc: "Mapea la salida hacia la laptop del desarrollador" },
                    { code: "0023", label: "Entrada DisplayPort", desc: "Mapea la entrada digital del sintetizador FPGA" },
                    { code: "0024", label: "Entrada AV Component", desc: "Mapea el puerto analógico de consolas heredadas" },
                    { code: "0025", label: "Entrada S-Video", desc: "Mapea el puerto de diagnóstico s-video de laboratorio" },
                    { code: "0026", label: "Entrada OTA Antenna", desc: "Mapea la entrada de sintonizador aéreo de RF terrestre" },
                  ].map((cmd) => (
                    <button
                      key={cmd.code}
                      onClick={() => evaluateBuffer(cmd.code)}
                      className="flex items-center justify-between p-2 rounded-xl border border-surface-variant bg-white/50 hover:bg-primary/5 hover:border-primary transition-all text-left group"
                    >
                      <div className="flex flex-col gap-0.5">
                        <span className="font-bold text-[11px] text-on-surface group-hover:text-primary transition-colors">{cmd.label}</span>
                        <span className="text-[10px] text-outline-variant line-clamp-1">{cmd.desc}</span>
                      </div>
                      <span className="font-mono text-[10px] font-bold bg-teal-50 text-teal-700 border border-teal-100 px-2 py-0.5 rounded shadow-sm group-hover:bg-primary group-hover:text-white transition-all">
                        {cmd.code}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* CATEGORY 4: SYSTEM APPLICATIONS */}
              <div>
                <h4 className="text-xs font-bold text-on-surface flex items-center gap-1 mb-2 sticky top-0 bg-white/90 backdrop-blur-sm py-1 z-10">
                  <span className="material-symbols-outlined text-xs text-purple-500">apps</span>
                  Lanzamiento de Aplicaciones (App Launcher)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {[
                    { code: "0031", label: "Iniciar Netflix", desc: "Lanza la aplicación de Netflix y carga contenido multimedia" },
                    { code: "0032", label: "Iniciar Spotify", desc: "Carga la playlist y el reproductor de música en streaming" },
                    { code: "0033", label: "Iniciar YouTube", desc: "Inicia la red de vídeo compartido en el sintonizador" },
                    { code: "0034", label: "Iniciar Prime Video", desc: "Abre el catálogo de películas de Amazon Prime Video" },
                    { code: "0035", label: "Iniciar Disney+", desc: "Carga la plataforma de entretenimiento de Disney" },
                    { code: "0036", label: "Iniciar Cable TV", desc: "Lanza la señal de radiodifusión televisiva aérea estándar" },
                  ].map((cmd) => (
                    <button
                      key={cmd.code}
                      onClick={() => evaluateBuffer(cmd.code)}
                      className="flex items-center justify-between p-2 rounded-xl border border-surface-variant bg-white/50 hover:bg-primary/5 hover:border-primary transition-all text-left group"
                    >
                      <div className="flex flex-col gap-0.5">
                        <span className="font-bold text-[11px] text-on-surface group-hover:text-primary transition-colors">{cmd.label}</span>
                        <span className="text-[10px] text-outline-variant line-clamp-1">{cmd.desc}</span>
                      </div>
                      <span className="font-mono text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-100 px-2 py-0.5 rounded shadow-sm group-hover:bg-primary group-hover:text-white transition-all">
                        {cmd.code}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* CATEGORY 5: REGISTER TOGGLE BITS */}
              <div>
                <h4 className="text-xs font-bold text-on-surface flex items-center gap-1 mb-2 sticky top-0 bg-white/90 backdrop-blur-sm py-1 z-10">
                  <span className="material-symbols-outlined text-xs text-indigo-500">memory</span>
                  Control de Bits de Registros (Register Toggles)
                </h4>
                <p className="text-[10px] text-outline mb-2">
                  Usa los códigos <code className="bg-slate-100 px-1 font-bold">004X</code>, <code className="bg-slate-100 px-1 font-bold">005X</code> o <code className="bg-slate-100 px-1 font-bold">006X</code> donde <code className="bg-slate-100 px-1 font-bold">X</code> es el bit (0 a 7) para alternar su estado.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  {/* Register Power */}
                  <div className="border border-surface-variant bg-slate-50/50 rounded-xl p-2 flex flex-col gap-1.5">
                    <span className="font-bold text-[10px] text-on-surface-variant flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                      Bits Register Power (0040-0047)
                    </span>
                    <div className="grid grid-cols-2 gap-1">
                      {[0, 1, 2, 3, 4, 5, 6, 7].map((bit) => (
                        <button
                          key={bit}
                          onClick={() => evaluateBuffer(`004${bit}`)}
                          className="flex items-center justify-between p-1 rounded border border-surface-variant bg-white hover:bg-primary/5 hover:border-primary text-[10px] group/btn"
                        >
                          <span className="text-outline font-medium">Bit {bit}</span>
                          <span className="font-mono font-bold text-blue-600 group-hover/btn:text-primary">004{bit}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Register Display */}
                  <div className="border border-surface-variant bg-slate-50/50 rounded-xl p-2 flex flex-col gap-1.5">
                    <span className="font-bold text-[10px] text-on-surface-variant flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                      Bits Register Display (0050-0057)
                    </span>
                    <div className="grid grid-cols-2 gap-1">
                      {[0, 1, 2, 3, 4, 5, 6, 7].map((bit) => (
                        <button
                          key={bit}
                          onClick={() => evaluateBuffer(`005${bit}`)}
                          className="flex items-center justify-between p-1 rounded border border-surface-variant bg-white hover:bg-primary/5 hover:border-primary text-[10px] group/btn"
                        >
                          <span className="text-outline font-medium">Bit {bit}</span>
                          <span className="font-mono font-bold text-green-600 group-hover/btn:text-primary">005{bit}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Register Data */}
                  <div className="border border-surface-variant bg-slate-50/50 rounded-xl p-2 flex flex-col gap-1.5">
                    <span className="font-bold text-[10px] text-on-surface-variant flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-yellow-500"></span>
                      Bits Register Data (0060-0067)
                    </span>
                    <div className="grid grid-cols-2 gap-1">
                      {[0, 1, 2, 3, 4, 5, 6, 7].map((bit) => (
                        <button
                          key={bit}
                          onClick={() => evaluateBuffer(`006${bit}`)}
                          className="flex items-center justify-between p-1 rounded border border-surface-variant bg-white hover:bg-primary/5 hover:border-primary text-[10px] group/btn"
                        >
                          <span className="text-outline font-medium">Bit {bit}</span>
                          <span className="font-mono font-bold text-yellow-600 group-hover/btn:text-primary">006{bit}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* CATEGORY 6: ADMIN & HARDWARE OVERRIDES */}
              <div>
                <h4 className="text-xs font-bold text-on-surface flex items-center gap-1 mb-2 sticky top-0 bg-white/90 backdrop-blur-sm py-1 z-10">
                  <span className="material-symbols-outlined text-xs text-red-500">admin_panel_settings</span>
                  Administración y Fábrica (Administration)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {[
                    { code: "0099", label: "Sobrescribir REG Power", desc: "Escribe 0xFF (todo alto) en el registro de energía" },
                    { code: "0000", label: "Restablecer de Fábrica (Reset)", desc: "Reinicia todos los registros, volumen y configuraciones de la placa" },
                  ].map((cmd) => (
                    <button
                      key={cmd.code}
                      onClick={() => evaluateBuffer(cmd.code)}
                      className="flex items-center justify-between p-2 rounded-xl border border-surface-variant bg-white/50 hover:bg-primary/5 hover:border-primary transition-all text-left group"
                    >
                      <div className="flex flex-col gap-0.5">
                        <span className="font-bold text-[11px] text-on-surface group-hover:text-primary transition-colors">{cmd.label}</span>
                        <span className="text-[10px] text-outline-variant line-clamp-1">{cmd.desc}</span>
                      </div>
                      <span className="font-mono text-[10px] font-bold bg-red-100 text-red-800 border border-red-200 px-2 py-0.5 rounded shadow-sm group-hover:bg-primary group-hover:text-white transition-all">
                        {cmd.code}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================= */}
        {/* RIGHT COLUMN: CHANNEL Overlays, FPGA STATUS & VOLUME CONTROL */}
        {/* ========================================================= */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-3 md:gap-4 min-h-0">
          
          {/* NOW PLAYING TELEVISION OSD */}
          <div 
            className="glass-panel cinematic-bg flex flex-col justify-between h-[180px] md:h-[220px] lg:h-[35%] min-h-[180px] flex-shrink-0 relative overflow-hidden bg-cover bg-center transition-all duration-500" 
            style={{ backgroundImage: `url('${currentChannel.bgUrl}')` }}
            id="channel-osd-panel"
          >
            {/* Gradient overlay for text readability */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent z-0"></div>
            
            {/* TV Frame floating icon */}
            <div className="absolute -right-8 -bottom-8 opacity-10 z-0">
              <span className="material-symbols-outlined text-[120px] text-white fill-1">tv</span>
            </div>

            <div className="p-4 md:p-5 flex flex-col h-full relative z-10 justify-between">
              
              {/* OSD Top Row: Title & Status */}
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-[10px] text-white/90 tracking-widest font-bold uppercase drop-shadow-md">
                    REPRODUCIENDO AHORA
                  </h2>
                  <div className="text-5xl md:text-6xl font-black text-white leading-none tracking-tighter drop-shadow-lg flex items-baseline gap-2">
                    {currentChannel.id}
                    <span className="text-[11px] font-bold text-blue-300 tracking-wider">CH</span>
                  </div>
                  <h3 className="text-sm md:text-base font-bold text-white mt-1 drop-shadow-md line-clamp-1">
                    {currentChannel.name}
                  </h3>
                </div>
                
                {/* Channel Switch Quick Dropdown */}
                <div className="flex flex-col items-end gap-1.5">
                  <div className="osd-overlay px-2.5 py-1 flex items-center gap-1.5 shadow-lg">
                    <span className="material-symbols-outlined text-red-500 text-[11px] animate-pulse">fiber_manual_record</span>
                    <span className="text-[8px] uppercase font-bold tracking-widest text-white">En Vivo</span>
                  </div>
                  
                  {/* Channel Quick Selector - Read-only badge */}
                  <div className="osd-overlay px-2 py-0.5 border border-white/10 text-[8px] uppercase tracking-wider text-yellow-300 font-mono shadow-md">
                    Control Físico (Teclas A / B)
                  </div>
                </div>
              </div>

              {/* OSD Bottom Row: Signal status stats */}
              <div className="flex items-center gap-2 mt-auto">
                <div className="osd-overlay px-2.5 py-1.5 flex flex-wrap items-center gap-2 shadow-lg text-[10px]">
                  <span className="font-mono text-white/90">{currentChannel.resolution}</span>
                  <span className="w-1 h-1 rounded-full bg-white/40"></span>
                  <span className="font-mono text-white/90">{currentChannel.frequency}</span>
                  <span className="w-1 h-1 rounded-full bg-white/40"></span>
                  <span className="font-mono text-blue-300 flex items-center gap-1">
                    <span className="material-symbols-outlined text-[12px]">settings_input_hdmi</span> 
                    {currentInput}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* CONTROL DE AUDIO Y SONIDO CARD */}
          <div className="glass-panel p-4 md:p-5 flex-grow flex flex-col min-h-0" id="audio-control-panel">
            <div className="flex items-center gap-2 mb-3 border-b border-surface-variant/40 pb-2 flex-shrink-0">
              <div className="w-8 h-8 rounded-full bg-orange-50 flex items-center justify-center shadow-sm border border-orange-100">
                <span className="material-symbols-outlined text-orange-600 text-sm">volume_up</span>
              </div>
              <div>
                <h3 className="text-sm md:text-base font-bold text-on-surface leading-none">Control de Audio y Sonido</h3>
                <span className="text-[10px] text-outline block mt-0.5">Control de volumen del amplificador y altavoces</span>
              </div>
            </div>

            <div className="flex flex-row items-stretch gap-3 flex-grow min-h-0">
              {/* Left Side: Audio Waveform & Key bindings Info */}
              <div className="flex-grow flex flex-col justify-between bg-slate-50/50 rounded-xl p-3 border border-surface-variant/40 min-w-0">
                <div className="flex flex-col gap-0.5">
                  <span className="text-[9px] text-outline font-bold uppercase tracking-wider leading-none">Estado de Salida</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className={`w-2 h-2 rounded-full ${isMuted ? "bg-red-500" : "bg-green-500 animate-pulse"}`}></span>
                    <span className="text-xs font-bold text-on-surface">
                      {isMuted ? "Audio Silenciado (MUTE)" : "Salida Activa (ON)"}
                    </span>
                  </div>
                </div>

                {/* Simulated Waveform Visualization */}
                <div className="h-16 flex items-center justify-center gap-1 my-2 overflow-hidden">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map((bar) => {
                    // Predefined dynamic animation delays
                    const delay = (bar * 0.08).toFixed(2);
                    return (
                      <div
                        key={bar}
                        style={{
                          height: isMuted ? "3px" : "100%",
                          animation: isMuted ? "none" : `wave 1.2s ease-in-out infinite alternate`,
                          animationDelay: `${delay}s`,
                        }}
                        className={`w-1 rounded-full transition-all duration-300 ${
                          isMuted ? "bg-slate-300" : "bg-gradient-to-t from-orange-500 to-amber-500"
                        }`}
                      />
                    );
                  })}
                </div>

                {/* Quick info commands list */}
                <div className="flex flex-col gap-1 text-[9px] text-outline-variant font-medium mt-1">
                  <div className="flex justify-between border-b border-surface-variant/20 pb-1">
                    <span>Subir Vol. (+5%)</span>
                    <span className="font-mono font-bold bg-slate-100 px-1 rounded text-on-surface">Tecla C / 0003#</span>
                  </div>
                  <div className="flex justify-between border-b border-surface-variant/20 pb-1">
                    <span>Bajar Vol. (-5%)</span>
                    <span className="font-mono font-bold bg-slate-100 px-1 rounded text-on-surface">Tecla D / 0004#</span>
                  </div>
                  <div className="flex justify-between border-b border-surface-variant/20 pb-1">
                    <span>Silenciar</span>
                    <span className="font-mono font-bold bg-slate-100 px-1 rounded text-on-surface">Tecla * / 0005#</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Reactivar</span>
                    <span className="font-mono font-bold bg-slate-100 px-1 rounded text-on-surface">Tecla # / 0006#</span>
                  </div>
                </div>
              </div>

              {/* Right Side: The Slider Indicator */}
              <div className="w-16 md:w-20 bg-slate-50/50 rounded-xl border border-surface-variant/40 flex flex-col items-center py-3 justify-between flex-shrink-0">
                <span className="text-[8px] font-mono font-bold text-outline uppercase tracking-wider">MAX</span>

                {/* Slider Track container */}
                <div className="flex-grow py-2 flex flex-col items-center w-full relative">
                  <div 
                    className="volume-bar-container w-6 cursor-default"
                    title="Indicador de volumen de audio"
                  >
                    <div 
                      className={`volume-bar-fill w-full ${
                        isMuted 
                          ? "bg-slate-300 shadow-none h-[0px]!" 
                          : ""
                      }`}
                      style={{ height: isMuted ? "0%" : `${volume}%` }}
                    />
                  </div>
                </div>

                {/* Volume Percent Value */}
                <span className="font-mono text-xs md:text-sm font-bold text-on-surface tracking-tight select-none mt-1">
                  {isMuted ? "MUT" : `${volume}%`}
                </span>
                
                <span className="text-[8px] font-mono font-bold text-outline uppercase tracking-wider mt-1">MIN</span>
              </div>
            </div>
          </div>
        </div>

      </main>

      {/* Decorative tiny footer */}
      <footer className="w-full text-center py-2 text-[10px] text-outline mt-3 flex-shrink-0 flex items-center justify-center gap-4">
        <span>Sistema de Interfaz de Laboratorio Transmisor AT v3.2.14</span>
        <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-ping"></span>
        <span>Conexión Activa Segura: Socket FPGA Web</span>
      </footer>

    </div>
  );
}
